import Link from "next/link";
import { Leaf, Mail, MapPin, Phone } from "lucide-react";

import { NewsletterForm } from "@/components/newsletter-form";

const shopLinks = [
  { href: "/shop", label: "All Products" },
  { href: "/shop?category=Skincare", label: "Skincare" },
  { href: "/shop?category=Makeup", label: "Makeup" },
  { href: "/shop?category=Fragrance", label: "Fragrance" },
  { href: "/shop?category=Body", label: "Bath & Body" },
];

const helpLinks = [
  { href: "/cart", label: "Your Bag" },
  { href: "/checkout", label: "Checkout" },
  { href: "/admin", label: "Order Dashboard" },
  { href: "/#faq", label: "FAQ" },
  { href: "/#story", label: "Our Story" },
];

export function SiteFooter() {
  return (
    <footer id="newsletter" className="bg-[#fffcf8]">
      <div className="relative overflow-hidden bg-[#b97970] px-5 py-14 text-white lg:py-16">
        <div className="pointer-events-none absolute -right-24 -top-24 h-80 w-80 rounded-full border border-white/15" />
        <div className="pointer-events-none absolute -bottom-40 right-32 h-96 w-96 rounded-full border border-white/10" />
        <div className="relative mx-auto grid max-w-[1400px] items-center gap-8 lg:grid-cols-[1fr_1fr]">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.28em] text-white/75">
              Join the glow list
            </p>
            <h2 className="font-display mt-3 max-w-lg text-4xl leading-tight sm:text-5xl">
              A little beauty in your inbox.
            </h2>
            <p className="mt-4 max-w-md text-sm leading-6 text-white/80">
              Be first to know about new formulas, quiet rituals and exclusive offers. Enjoy 10% off your first order.
            </p>
          </div>
          <div className="lg:justify-self-end lg:pr-10">
            <NewsletterForm />
            <p className="mt-4 text-[10px] uppercase tracking-[0.16em] text-white/65">
              No clutter. Just thoughtful notes.
            </p>
          </div>
        </div>
      </div>

      <div className="mx-auto grid max-w-[1400px] gap-10 px-5 py-14 sm:grid-cols-2 lg:grid-cols-[1.5fr_1fr_1fr_1.2fr] lg:px-10">
        <div>
          <Link href="/" className="font-display text-3xl tracking-[0.08em] text-[#2d2420]">
            LUMIÈRE
          </Link>
          <p className="mt-4 max-w-xs text-sm leading-6 text-[#7b6f68]">
            Considered beauty for the everyday ritual. Clean formulas, sensorial textures and a little moment of calm in every bottle.
          </p>
          <div className="mt-6 flex items-center gap-2 text-xs font-medium uppercase tracking-[0.14em] text-[#9c8d83]">
            <Leaf size={16} className="text-[#9daa89]" /> Cruelty-free & thoughtfully made
          </div>
        </div>

        <div>
          <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[#2d2420]">Shop</h3>
          <ul className="mt-5 space-y-3">
            {shopLinks.map((link) => (
              <li key={link.label}>
                <Link href={link.href} className="text-sm text-[#7b6f68] transition hover:text-[#b47c6f]">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[#2d2420]">Help</h3>
          <ul className="mt-5 space-y-3">
            {helpLinks.map((link) => (
              <li key={link.label}>
                <Link href={link.href} className="text-sm text-[#7b6f68] transition hover:text-[#b47c6f]">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[#2d2420]">Visit & Connect</h3>
          <ul className="mt-5 space-y-3 text-sm text-[#7b6f68]">
            <li className="flex items-start gap-2"><MapPin size={15} className="mt-0.5 text-[#b47c6f]" /> 18 Rose Lane, New York, NY</li>
            <li className="flex items-center gap-2"><Mail size={15} className="text-[#b47c6f]" /> hello@lumierebeauty.com</li>
            <li className="flex items-center gap-2"><Phone size={15} className="text-[#b47c6f]" /> +1 (212) 555 0148</li>
          </ul>
          <div className="mt-6 flex gap-2">
            <a href="https://instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram" className="grid h-9 w-9 place-items-center rounded-full border border-[#e5dbd2] text-[#755f57] transition hover:bg-[#f5eee8]">
              <span className="text-[10px] font-bold tracking-[0.08em]">IG</span>
            </a>
            <span className="grid h-9 w-9 place-items-center rounded-full border border-[#e5dbd2] font-display text-sm text-[#755f57]">P</span>
            <span className="grid h-9 w-9 place-items-center rounded-full border border-[#e5dbd2] font-display text-sm text-[#755f57]">T</span>
          </div>
        </div>
      </div>

      <div className="border-t border-[#e9e0d8]">
        <div className="mx-auto flex max-w-[1400px] flex-col items-center justify-between gap-3 px-5 py-5 text-[11px] text-[#9c8d83] sm:flex-row lg:px-10">
          <p>© {new Date().getFullYear()} Lumière Beauty Studio. All rights reserved.</p>
          <p className="flex items-center gap-4">
            <span>Privacy</span><span>Terms</span><span>Secure checkout</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
