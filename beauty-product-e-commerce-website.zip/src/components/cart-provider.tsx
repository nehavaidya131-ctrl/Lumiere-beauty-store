"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  ArrowRight,
  Minus,
  Plus,
  ShoppingBag,
  Trash2,
  X,
} from "lucide-react";
import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";

import { formatPrice } from "@/lib/format";
import {
  FREE_SHIPPING_CENTS,
  STANDARD_SHIPPING_CENTS,
  type CartItem,
} from "@/lib/types";

const STORAGE_KEY = "lumiere-beauty-cart-v1";

type CartProduct = Omit<CartItem, "quantity">;

interface CartContextValue {
  items: CartItem[];
  count: number;
  subtotal: number;
  shipping: number;
  total: number;
  hydrated: boolean;
  isOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  addItem: (product: CartProduct, quantity?: number) => void;
  setQuantity: (id: number, quantity: number) => void;
  removeItem: (id: number) => void;
  clearCart: () => void;
}

const CartContext = createContext<CartContextValue | null>(null);

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart must be used inside CartProvider");
  return context;
}

function sanitizeItems(value: unknown): CartItem[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter(
      (item): item is CartItem =>
        typeof item === "object" &&
        item !== null &&
        typeof item.id === "number" &&
        typeof item.name === "string" &&
        typeof item.imageUrl === "string" &&
        typeof item.priceCents === "number" &&
        typeof item.quantity === "number",
    )
    .map((item) => ({
      ...item,
      quantity: Math.max(1, Math.min(20, Math.round(item.quantity))),
    }));
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) setItems(sanitizeItems(JSON.parse(stored)));
    } catch {
      // Ignore malformed local cart data.
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }, [items, hydrated]);

  useEffect(() => {
    setIsOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  const count = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce(
    (sum, item) => sum + item.priceCents * item.quantity,
    0,
  );
  const shipping =
    subtotal === 0 || subtotal >= FREE_SHIPPING_CENTS
      ? 0
      : STANDARD_SHIPPING_CENTS;
  const total = subtotal + shipping;

  const addItem = (product: CartProduct, quantity = 1) => {
    const amount = Math.max(1, Math.min(20, Math.round(quantity)));
    setItems((current) => {
      const existing = current.find((item) => item.id === product.id);
      if (existing) {
        return current.map((item) =>
          item.id === product.id
            ? { ...item, quantity: Math.min(20, item.quantity + amount) }
            : item,
        );
      }
      return [...current, { ...product, quantity: amount }];
    });
    setIsOpen(true);
  };

  const setQuantity = (id: number, quantity: number) => {
    if (quantity < 1) {
      setItems((current) => current.filter((item) => item.id !== id));
      return;
    }
    setItems((current) =>
      current.map((item) =>
        item.id === id
          ? { ...item, quantity: Math.min(20, Math.round(quantity)) }
          : item,
      ),
    );
  };

  const removeItem = (id: number) => {
    setItems((current) => current.filter((item) => item.id !== id));
  };

  const clearCart = () => setItems([]);

  const value: CartContextValue = {
    items,
    count,
    subtotal,
    shipping,
    total,
    hydrated,
    isOpen,
    openCart: () => setIsOpen(true),
    closeCart: () => setIsOpen(false),
    addItem,
    setQuantity,
    removeItem,
    clearCart,
  };

  return (
    <CartContext.Provider value={value}>
      {children}
      {isOpen && (
        <div className="fixed inset-0 z-[100]">
          <button
            type="button"
            aria-label="Close shopping bag"
            onClick={() => setIsOpen(false)}
            className="absolute inset-0 h-full w-full bg-[#2b211d]/45 backdrop-blur-[2px]"
          />
          <aside className="animate-slide-in absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-[#fffcf8] shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#e9dfd6] px-6 py-5">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-[#b47c6f]">
                  Your selection
                </p>
                <h2 className="font-display mt-1 text-2xl text-[#2d2420]">
                  Shopping Bag <span className="text-[#988c83]">({count})</span>
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                aria-label="Close bag"
                className="grid h-10 w-10 place-items-center rounded-full border border-[#e9dfd6] text-[#5c5049] transition hover:bg-[#f5eee8]"
              >
                <X size={18} />
              </button>
            </div>

            {items.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
                <div className="grid h-20 w-20 place-items-center rounded-full bg-[#f2e8e2] text-[#b47c6f]">
                  <ShoppingBag size={30} strokeWidth={1.4} />
                </div>
                <h3 className="font-display mt-6 text-2xl text-[#2d2420]">
                  Your bag is waiting
                </h3>
                <p className="mt-2 text-sm leading-6 text-[#796e67]">
                  Discover thoughtful formulas made to make every day feel a little more beautiful.
                </p>
                <Link
                  href="/shop"
                  onClick={() => setIsOpen(false)}
                  className="mt-7 rounded-full bg-[#2d2420] px-7 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-white transition hover:bg-[#b47c6f]"
                >
                  Explore products
                </Link>
              </div>
            ) : (
              <>
                <div className="flex-1 space-y-5 overflow-y-auto px-6 py-6">
                  {shipping > 0 && (
                    <div className="rounded-2xl bg-[#f6eee8] px-4 py-3 text-xs leading-5 text-[#6e5c53]">
                      You&apos;re <strong>{formatPrice(FREE_SHIPPING_CENTS - subtotal)}</strong> away from complimentary shipping.
                    </div>
                  )}
                  {items.map((item) => (
                    <div key={item.id} className="flex gap-4 border-b border-[#eee6de] pb-5">
                      <Link
                        href={`/product/${item.slug}`}
                        onClick={() => setIsOpen(false)}
                        className="h-28 w-24 shrink-0 overflow-hidden rounded-xl bg-[#f0e9e2]"
                      >
                        <img
                          src={item.imageUrl}
                          alt={item.name}
                          className="h-full w-full object-cover"
                        />
                      </Link>
                      <div className="flex min-w-0 flex-1 flex-col">
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <p className="text-[10px] uppercase tracking-[0.18em] text-[#aa9b91]">
                              {item.brand}
                            </p>
                            <Link
                              href={`/product/${item.slug}`}
                              onClick={() => setIsOpen(false)}
                              className="font-display mt-1 block text-lg leading-tight text-[#2d2420]"
                            >
                              {item.name}
                            </Link>
                          </div>
                          <button
                            type="button"
                            onClick={() => removeItem(item.id)}
                            aria-label={`Remove ${item.name}`}
                            className="text-[#aa9b91] transition hover:text-[#b47c6f]"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                        <div className="mt-auto flex items-center justify-between pt-3">
                          <div className="flex items-center rounded-full border border-[#e4d9cf]">
                            <button
                              type="button"
                              onClick={() => setQuantity(item.id, item.quantity - 1)}
                              aria-label="Decrease quantity"
                              className="grid h-8 w-8 place-items-center text-[#6d6059]"
                            >
                              <Minus size={13} />
                            </button>
                            <span className="w-6 text-center text-sm">{item.quantity}</span>
                            <button
                              type="button"
                              onClick={() => setQuantity(item.id, item.quantity + 1)}
                              aria-label="Increase quantity"
                              className="grid h-8 w-8 place-items-center text-[#6d6059]"
                            >
                              <Plus size={13} />
                            </button>
                          </div>
                          <span className="text-sm font-semibold text-[#2d2420]">
                            {formatPrice(item.priceCents * item.quantity)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t border-[#e9dfd6] bg-white px-6 py-5">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between text-[#796e67]">
                      <span>Subtotal</span>
                      <span>{formatPrice(subtotal)}</span>
                    </div>
                    <div className="flex justify-between text-[#796e67]">
                      <span>Shipping</span>
                      <span>{shipping === 0 ? "Complimentary" : formatPrice(shipping)}</span>
                    </div>
                    <div className="font-display flex justify-between border-t border-[#eee6de] pt-3 text-xl text-[#2d2420]">
                      <span>Total</span>
                      <span>{formatPrice(total)}</span>
                    </div>
                  </div>
                  <Link
                    href="/checkout"
                    onClick={() => setIsOpen(false)}
                    className="mt-5 flex items-center justify-center gap-2 rounded-full bg-[#2d2420] py-3.5 text-xs font-semibold uppercase tracking-[0.16em] text-white transition hover:bg-[#b47c6f]"
                  >
                    Checkout <ArrowRight size={15} />
                  </Link>
                  <Link
                    href="/cart"
                    onClick={() => setIsOpen(false)}
                    className="mt-3 block text-center text-xs font-semibold uppercase tracking-[0.14em] text-[#796e67] underline underline-offset-4"
                  >
                    View full bag
                  </Link>
                </div>
              </>
            )}
          </aside>
        </div>
      )}
    </CartContext.Provider>
  );
}
