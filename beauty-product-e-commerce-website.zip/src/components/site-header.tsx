"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, Search, ShoppingBag, Sparkles, X } from "lucide-react";
import { useState } from "react";

import { useCart } from "@/components/cart-provider";

const navigation = [
  { href: "/shop", label: "Shop All" },
  { href: "/shop?category=Skincare", label: "Skincare" },
  { href: "/shop?category=Makeup", label: "Makeup" },
  { href: "/shop?category=Fragrance", label: "Fragrance" },
  { href: "/shop?category=Body", label: "Body" },
  { href: "/#story", label: "Our Story" },
];

export function SiteHeader() {
  const pathname = usePathname();
  const { count, openCart } = useCart();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50">
      <div className="bg-[#3b2c28] px-4 py-2 text-center text-[10px] font-medium uppercase tracking-[0.22em] text-[#f8eee8] sm:text-[11px]">
        Complimentary shipping on orders over $50 <span className="mx-2 text-[#c99a8d]">✦</span> A gift with every order
      </div>
      <div className="border-b border-[#e9e0d8] bg-[#fffcf8]/95 backdrop-blur-md">
        <div className="mx-auto flex h-[76px] max-w-[1400px] items-center justify-between gap-5 px-5 lg:px-10">
          <button
            type="button"
            className="grid h-10 w-10 place-items-center text-[#3b2c28] lg:hidden"
            aria-label="Open menu"
            onClick={() => setMobileOpen((open) => !open)}
          >
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>

          <Link href="/" className="flex items-center gap-3" aria-label="Lumière Beauty home">
            <span className="grid h-10 w-10 place-items-center rounded-full border border-[#cbb5a8] bg-[#f5ece6] text-[#b47c6f]">
              <Sparkles size={17} strokeWidth={1.5} />
            </span>
            <span className="leading-none">
              <span className="font-display block text-2xl tracking-[0.08em] text-[#2d2420]">
                LUMIÈRE
              </span>
              <span className="mt-1 block text-[8px] font-semibold uppercase tracking-[0.42em] text-[#a38f84]">
                Beauty Studio
              </span>
            </span>
          </Link>

          <nav className="hidden items-center gap-7 lg:flex">
            {navigation.map((item) => {
              const active =
                item.href === "/shop"
                  ? pathname === "/shop"
                  : item.href.startsWith("/shop?") && pathname === "/shop";
              return (
                <Link
                  key={item.label}
                  href={item.href}
                  className={`relative text-[11px] font-semibold uppercase tracking-[0.15em] transition hover:text-[#b47c6f] ${
                    active && item.href === "/shop" ? "text-[#b47c6f]" : "text-[#574c46]"
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-2 sm:gap-3">
            <form action="/shop" method="get" className="hidden items-center rounded-full border border-[#e5dbd2] bg-white px-4 py-2 xl:flex">
              <Search size={15} className="text-[#9c8d83]" />
              <input
                type="search"
                name="q"
                placeholder="Search beauty..."
                aria-label="Search products"
                className="w-36 bg-transparent px-3 text-xs text-[#3b2c28] outline-none placeholder:text-[#ab9e95]"
              />
            </form>
            <Link
              href="/shop"
              className="grid h-10 w-10 place-items-center rounded-full text-[#3b2c28] transition hover:bg-[#f5eee8] xl:hidden"
              aria-label="Search products"
            >
              <Search size={19} />
            </Link>
            <Link
              href="/admin"
              className="hidden text-[10px] font-semibold uppercase tracking-[0.14em] text-[#8b7d74] transition hover:text-[#b47c6f] sm:block"
            >
              Admin
            </Link>
            <button
              type="button"
              onClick={openCart}
              aria-label={`Open shopping bag with ${count} items`}
              className="relative grid h-10 w-10 place-items-center rounded-full border border-[#e5dbd2] bg-white text-[#3b2c28] transition hover:bg-[#f5eee8]"
            >
              <ShoppingBag size={18} strokeWidth={1.7} />
              {count > 0 && (
                <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-[#b47c6f] px-1 text-[10px] font-bold text-white">
                  {count}
                </span>
              )}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <div className="border-t border-[#e9e0d8] bg-[#fffcf8] px-5 py-5 lg:hidden">
            <form action="/shop" method="get" className="mb-5 flex items-center rounded-full border border-[#e5dbd2] bg-white px-4 py-3">
              <Search size={16} className="text-[#9c8d83]" />
              <input
                type="search"
                name="q"
                placeholder="Search beauty..."
                aria-label="Search products"
                className="w-full bg-transparent px-3 text-sm outline-none"
              />
            </form>
            <nav className="grid grid-cols-2 gap-y-1">
              {navigation.map((item) => (
                <Link
                  key={item.label}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className="rounded-xl px-3 py-3 text-xs font-semibold uppercase tracking-[0.14em] text-[#574c46] hover:bg-[#f5eee8]"
                >
                  {item.label}
                </Link>
              ))}
              <Link
                href="/admin"
                onClick={() => setMobileOpen(false)}
                className="rounded-xl px-3 py-3 text-xs font-semibold uppercase tracking-[0.14em] text-[#574c46] hover:bg-[#f5eee8]"
              >
                Admin
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
