"use client";

import { Check, ShoppingBag } from "lucide-react";
import { useEffect, useState } from "react";

import { useCart } from "@/components/cart-provider";
import type { Product } from "@/lib/types";

interface AddToCartButtonProps {
  product: Product;
  quantity?: number;
  label?: string;
  className?: string;
  showIcon?: boolean;
}

export function AddToCartButton({
  product,
  quantity = 1,
  label = "Add to bag",
  className = "",
  showIcon = true,
}: AddToCartButtonProps) {
  const { addItem } = useCart();
  const [added, setAdded] = useState(false);

  useEffect(() => {
    if (!added) return;
    const timeout = window.setTimeout(() => setAdded(false), 1800);
    return () => window.clearTimeout(timeout);
  }, [added]);

  if (product.stock < 1) {
    return (
      <button
        type="button"
        disabled
        className={`cursor-not-allowed rounded-full bg-[#ddd3cb] px-5 py-3 text-xs font-semibold uppercase tracking-[0.15em] text-white ${className}`}
      >
        Sold out
      </button>
    );
  }

  return (
    <button
      type="button"
      onClick={() => {
        addItem(
          {
            id: product.id,
            slug: product.slug,
            name: product.name,
            brand: product.brand,
            imageUrl: product.imageUrl,
            priceCents: product.priceCents,
          },
          quantity,
        );
        setAdded(true);
      }}
      className={`inline-flex items-center justify-center gap-2 rounded-full text-xs font-semibold uppercase tracking-[0.14em] transition ${className}`}
    >
      {showIcon && (added ? <Check size={15} /> : <ShoppingBag size={15} />)}
      {added ? "Added to bag" : label}
    </button>
  );
}
