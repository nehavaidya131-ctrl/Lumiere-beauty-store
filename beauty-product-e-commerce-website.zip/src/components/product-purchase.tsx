"use client";

import { ChevronDown, Leaf, Minus, Plus, ShieldCheck, Truck } from "lucide-react";
import { useState } from "react";

import { AddToCartButton } from "@/components/add-to-cart-button";
import { formatPrice } from "@/lib/format";
import type { Product } from "@/lib/types";

const accordion = [
  { title: "Details", key: "details" },
  { title: "Key ingredients", key: "ingredients" },
  { title: "How to use", key: "howToUse" },
] as const;

export function ProductPurchase({ product }: { product: Product }) {
  const [quantity, setQuantity] = useState(1);

  return (
    <div>
      <div className="mt-7 flex flex-wrap items-center gap-3">
        <div className="flex h-12 items-center rounded-full border border-[#e2d7ce] bg-white">
          <button
            type="button"
            aria-label="Decrease quantity"
            onClick={() => setQuantity((value) => Math.max(1, value - 1))}
            className="grid h-12 w-11 place-items-center text-[#675a53] transition hover:text-[#b47c6f]"
          >
            <Minus size={15} />
          </button>
          <span className="w-8 text-center text-sm font-semibold text-[#2d2420]">{quantity}</span>
          <button
            type="button"
            aria-label="Increase quantity"
            onClick={() => setQuantity((value) => Math.min(20, value + 1))}
            className="grid h-12 w-11 place-items-center text-[#675a53] transition hover:text-[#b47c6f]"
          >
            <Plus size={15} />
          </button>
        </div>
        <AddToCartButton
          product={product}
          quantity={quantity}
          label={`Add to bag — ${formatPrice(product.priceCents * quantity)}`}
          className="min-h-12 flex-1 bg-[#2d2420] px-7 text-white shadow-lg shadow-[#2d2420]/10 hover:bg-[#b47c6f]"
        />
      </div>

      <div className="mt-5 flex flex-wrap gap-x-6 gap-y-2 text-xs text-[#7b6f68]">
        <span className="flex items-center gap-2"><Truck size={15} className="text-[#b47c6f]" /> Free shipping over $50</span>
        <span className="flex items-center gap-2"><ShieldCheck size={15} className="text-[#b47c6f]" /> 30-day easy returns</span>
        <span className="flex items-center gap-2"><Leaf size={15} className="text-[#9daa89]" /> Cruelty-free formula</span>
      </div>

      <div className="mt-9 border-t border-[#e9e0d8]">
        {accordion.map((item, index) => (
          <details key={item.key} open={index === 0} className="group border-b border-[#e9e0d8] py-4">
            <summary className="flex cursor-pointer list-none items-center justify-between text-xs font-semibold uppercase tracking-[0.16em] text-[#3b2c28] [&::-webkit-details-marker]:hidden">
              {item.title}
              <ChevronDown size={16} className="text-[#a38f84] transition group-open:rotate-180" />
            </summary>
            <p className="mt-3 pr-6 text-sm leading-6 text-[#7b6f68]">{product[item.key]}</p>
          </details>
        ))}
      </div>
    </div>
  );
}
