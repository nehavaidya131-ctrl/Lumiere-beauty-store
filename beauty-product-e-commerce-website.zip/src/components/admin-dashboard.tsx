"use client";

import { useRouter } from "next/navigation";
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  Loader2,
  Package,
  Plus,
  ShoppingBag,
  TrendingUp,
} from "lucide-react";
import { useState, type FormEvent } from "react";

import { formatDate, formatPrice } from "@/lib/format";
import { ORDER_STATUSES, type OrderRecord, type Product } from "@/lib/types";

interface AdminStats {
  revenue: number;
  orderCount: number;
  average: number;
  productCount: number;
  lowStock: number;
}

interface AdminDashboardProps {
  orders: OrderRecord[];
  products: Product[];
  stats: AdminStats;
}

export function AdminDashboard({ orders, products, stats }: AdminDashboardProps) {
  const router = useRouter();
  const [busyId, setBusyId] = useState<number | null>(null);
  const [creating, setCreating] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  async function updateStatus(id: number, status: string) {
    setBusyId(id);
    setNotice("");
    setError("");
    try {
      const response = await fetch(`/api/orders/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      const data = (await response.json()) as { message?: string };
      if (!response.ok) throw new Error(data.message ?? "Could not update status.");
      setNotice("Order status updated.");
      router.refresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not update status.");
    } finally {
      setBusyId(null);
    }
  }

  async function createProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const data = new FormData(formElement);
    setCreating(true);
    setNotice("");
    setError("");
    try {
      const response = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: String(data.get("name") ?? ""),
          brand: String(data.get("brand") ?? ""),
          category: String(data.get("category") ?? ""),
          price: Number(data.get("price") ?? 0),
          stock: Number(data.get("stock") ?? 0),
          imageUrl: String(data.get("imageUrl") ?? ""),
          description: String(data.get("description") ?? ""),
          badge: String(data.get("badge") ?? ""),
        }),
      });
      const result = (await response.json()) as { message?: string };
      if (!response.ok) throw new Error(result.message ?? "Could not add product.");
      formElement.reset();
      setFormOpen(false);
      setNotice("Product added to the catalog.");
      router.refresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not add product.");
    } finally {
      setCreating(false);
    }
  }

  return (
    <div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Revenue", value: formatPrice(stats.revenue), icon: TrendingUp, note: "Excludes cancelled orders" },
          { label: "Orders", value: String(stats.orderCount), icon: ShoppingBag, note: `${orders.filter((order) => order.status === "pending").length} pending` },
          { label: "Products", value: String(stats.productCount), icon: Package, note: "Live catalog items" },
          { label: "Low stock", value: String(stats.lowStock), icon: AlertTriangle, note: "10 units or fewer" },
        ].map((stat) => (
          <div key={stat.label} className="rounded-2xl border border-[#e9e0d8] bg-white p-5">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-[#9c8d83]">{stat.label}</p>
              <stat.icon size={17} className="text-[#b47c6f]" />
            </div>
            <p className="font-display mt-3 text-3xl text-[#2d2420]">{stat.value}</p>
            <p className="mt-1 text-[11px] text-[#9c8d83]">{stat.note}</p>
          </div>
        ))}
      </div>

      {notice && <p className="mt-6 flex items-center gap-2 rounded-xl bg-[#edf4eb] px-4 py-3 text-sm text-[#657d5c]"><CheckCircle2 size={16} /> {notice}</p>}
      {error && <p role="alert" className="mt-6 rounded-xl bg-[#fff0ec] px-4 py-3 text-sm text-[#a04f45]">{error}</p>}

      <section className="mt-8 rounded-[1.5rem] border border-[#e9e0d8] bg-white">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#eee5dd] px-6 py-5">
          <div>
            <h2 className="font-display text-2xl">Recent orders</h2>
            <p className="mt-1 text-xs text-[#9c8d83]">Update fulfillment status as orders move along.</p>
          </div>
          <span className="rounded-full bg-[#f4e7e1] px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-[#a9605b]">Live database</span>
        </div>
        {orders.length === 0 ? (
          <div className="px-6 py-14 text-center">
            <p className="font-display text-2xl">No orders yet</p>
            <p className="mt-2 text-sm text-[#796e67]">Place a test order from the storefront and it will appear here.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[780px] text-left text-sm">
              <thead className="bg-[#fbf7f3] text-[10px] uppercase tracking-[0.14em] text-[#9c8d83]">
                <tr><th className="px-6 py-3 font-semibold">Order</th><th className="px-4 py-3 font-semibold">Customer</th><th className="px-4 py-3 font-semibold">Date</th><th className="px-4 py-3 font-semibold">Items</th><th className="px-4 py-3 font-semibold">Total</th><th className="px-6 py-3 font-semibold">Status</th></tr>
              </thead>
              <tbody className="divide-y divide-[#eee5dd]">
                {orders.map((order) => (
                  <tr key={order.id} className="text-[#574c46]">
                    <td className="px-6 py-4 font-semibold text-[#2d2420]">{order.orderNumber}</td>
                    <td className="px-4 py-4"><span>{order.customerName}</span><span className="block text-xs text-[#9c8d83]">{order.email}</span></td>
                    <td className="px-4 py-4 text-xs">{formatDate(order.createdAt)}</td>
                    <td className="px-4 py-4">{order.items.reduce((sum, item) => sum + item.quantity, 0)}</td>
                    <td className="px-4 py-4 font-semibold text-[#2d2420]">{formatPrice(order.totalCents)}</td>
                    <td className="px-6 py-4">
                      <div className="relative inline-flex items-center">
                        <select
                          value={order.status}
                          disabled={busyId === order.id}
                          onChange={(event) => updateStatus(order.id, event.target.value)}
                          aria-label={`Status for ${order.orderNumber}`}
                          className="appearance-none rounded-full border border-[#e2d7ce] bg-[#fbf7f3] py-2 pl-3 pr-8 text-xs font-semibold capitalize text-[#5c5049] outline-none disabled:opacity-50"
                        >
                          {ORDER_STATUSES.map((status) => <option key={status} value={status}>{status}</option>)}
                        </select>
                        {busyId === order.id ? <Loader2 size={13} className="absolute right-2 animate-spin text-[#b47c6f]" /> : <ChevronDown size={13} className="pointer-events-none absolute right-2 text-[#9c8d83]" />}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section className="mt-8 rounded-[1.5rem] border border-[#e9e0d8] bg-white">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#eee5dd] px-6 py-5">
          <div>
            <h2 className="font-display text-2xl">Inventory</h2>
            <p className="mt-1 text-xs text-[#9c8d83]">Manage the live product catalog and keep an eye on stock.</p>
          </div>
          <button type="button" onClick={() => setFormOpen((open) => !open)} className="inline-flex items-center gap-2 rounded-full bg-[#2d2420] px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-white hover:bg-[#b47c6f]">
            <Plus size={14} /> Add product
          </button>
        </div>

        {formOpen && (
          <form onSubmit={createProduct} className="grid gap-4 border-b border-[#eee5dd] bg-[#fbf7f3] p-6 sm:grid-cols-2 lg:grid-cols-3">
            <label className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#8a7c73]">Product name *
              <input required name="name" className="mt-2 w-full rounded-xl border border-[#e5dad1] bg-white px-3 py-2.5 text-sm font-normal normal-case tracking-normal text-[#2d2420] outline-none" placeholder="Rose Dew Mist" />
            </label>
            <label className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#8a7c73]">Brand
              <input name="brand" className="mt-2 w-full rounded-xl border border-[#e5dad1] bg-white px-3 py-2.5 text-sm font-normal normal-case tracking-normal text-[#2d2420] outline-none" placeholder="Lumière Lab" />
            </label>
            <label className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#8a7c73]">Category
              <select name="category" className="mt-2 w-full rounded-xl border border-[#e5dad1] bg-white px-3 py-2.5 text-sm font-normal normal-case tracking-normal text-[#2d2420] outline-none">
                <option>Skincare</option><option>Makeup</option><option>Fragrance</option><option>Body</option>
              </select>
            </label>
            <label className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#8a7c73]">Price (USD) *
              <input required name="price" type="number" min="1" step="0.01" className="mt-2 w-full rounded-xl border border-[#e5dad1] bg-white px-3 py-2.5 text-sm font-normal normal-case tracking-normal text-[#2d2420] outline-none" placeholder="32.00" />
            </label>
            <label className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#8a7c73]">Stock
              <input name="stock" type="number" min="0" step="1" defaultValue="30" className="mt-2 w-full rounded-xl border border-[#e5dad1] bg-white px-3 py-2.5 text-sm font-normal normal-case tracking-normal text-[#2d2420] outline-none" />
            </label>
            <label className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#8a7c73]">Badge
              <input name="badge" className="mt-2 w-full rounded-xl border border-[#e5dad1] bg-white px-3 py-2.5 text-sm font-normal normal-case tracking-normal text-[#2d2420] outline-none" placeholder="New" />
            </label>
            <label className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#8a7c73] sm:col-span-2 lg:col-span-2">Image URL
              <input name="imageUrl" type="url" className="mt-2 w-full rounded-xl border border-[#e5dad1] bg-white px-3 py-2.5 text-sm font-normal normal-case tracking-normal text-[#2d2420] outline-none" placeholder="https://..." />
            </label>
            <label className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#8a7c73] sm:col-span-2 lg:col-span-3">Description *
              <textarea required name="description" rows={2} className="mt-2 w-full resize-none rounded-xl border border-[#e5dad1] bg-white px-3 py-2.5 text-sm font-normal normal-case tracking-normal text-[#2d2420] outline-none" placeholder="A refreshing facial mist..." />
            </label>
            <div className="flex items-center gap-3 sm:col-span-2 lg:col-span-3">
              <button type="submit" disabled={creating} className="inline-flex items-center gap-2 rounded-full bg-[#b47c6f] px-6 py-2.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-white disabled:opacity-60">
                {creating && <Loader2 size={13} className="animate-spin" />} Save product
              </button>
              <button type="button" onClick={() => setFormOpen(false)} className="text-[10px] font-semibold uppercase tracking-[0.14em] text-[#8a7c73]">Cancel</button>
            </div>
          </form>
        )}

        <div className="overflow-x-auto">
          <table className="w-full min-w-[700px] text-left text-sm">
            <thead className="bg-[#fbf7f3] text-[10px] uppercase tracking-[0.14em] text-[#9c8d83]">
              <tr><th className="px-6 py-3 font-semibold">Product</th><th className="px-4 py-3 font-semibold">Category</th><th className="px-4 py-3 font-semibold">Price</th><th className="px-4 py-3 font-semibold">Rating</th><th className="px-6 py-3 font-semibold">Stock</th></tr>
            </thead>
            <tbody className="divide-y divide-[#eee5dd]">
              {products.map((product) => (
                <tr key={product.id} className="text-[#574c46]">
                  <td className="px-6 py-3">
                    <div className="flex items-center gap-3">
                      <img src={product.imageUrl} alt="" className="h-11 w-9 rounded-md object-cover" />
                      <div><p className="font-medium text-[#2d2420]">{product.name}</p><p className="text-xs text-[#9c8d83]">{product.brand}</p></div>
                    </div>
                  </td>
                  <td className="px-4 py-3">{product.category}</td>
                  <td className="px-4 py-3 font-semibold">{formatPrice(product.priceCents)}</td>
                  <td className="px-4 py-3">{(product.rating / 10).toFixed(1)} ★</td>
                  <td className="px-6 py-3">
                    <span className={`rounded-full px-3 py-1 text-xs font-semibold ${product.stock <= 10 ? "bg-[#fff0e3] text-[#ad6f38]" : "bg-[#edf4eb] text-[#657d5c]"}`}>
                      {product.stock} units
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
