"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Check, Loader2, ShieldCheck } from "lucide-react";
import { useState, type ChangeEvent, type FormEvent } from "react";

import { useCart } from "@/components/cart-provider";
import { formatPrice } from "@/lib/format";

const initialForm = {
  customerName: "",
  email: "",
  phone: "",
  address: "",
  city: "",
  postalCode: "",
  country: "United States",
  notes: "",
};

type FormState = typeof initialForm;

export function CheckoutForm() {
  const router = useRouter();
  const { items, hydrated, subtotal, shipping, total, clearCart } = useCart();
  const [form, setForm] = useState<FormState>(initialForm);
  const [paymentMethod, setPaymentMethod] = useState("card");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const update = (key: keyof FormState) =>
    (event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm((current) => ({ ...current, [key]: event.target.value }));

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (items.length === 0 || submitting) return;
    setSubmitting(true);
    setError("");

    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          paymentMethod,
          items: items.map((item) => ({ productId: item.id, quantity: item.quantity })),
        }),
      });
      const data = (await response.json()) as { orderNumber?: string; message?: string };
      if (!response.ok || !data.orderNumber) {
        throw new Error(data.message ?? "We could not place your order. Please try again.");
      }
      clearCart();
      router.push(`/orders/${data.orderNumber}`);
      router.refresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Something went wrong. Please try again.");
      setSubmitting(false);
    }
  }

  if (!hydrated) {
    return <div className="grid min-h-[50vh] place-items-center text-sm text-[#9c8d83]">Preparing checkout…</div>;
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-xl px-5 py-24 text-center">
        <h1 className="font-display text-4xl">Nothing to check out yet</h1>
        <p className="mt-3 text-sm leading-6 text-[#796e67]">Add a few favorites to your bag and come back when you are ready.</p>
        <Link href="/shop" className="mt-7 inline-block rounded-full bg-[#2d2420] px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.15em] text-white hover:bg-[#b47c6f]">
          Shop products
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1400px] px-5 py-12 lg:px-10 lg:py-16">
      <Link href="/cart" className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-[#8a7c73] hover:text-[#b47c6f]">
        <ArrowLeft size={14} /> Back to bag
      </Link>
      <h1 className="font-display mt-5 text-5xl">Checkout</h1>
      <p className="mt-3 text-sm text-[#796e67]">A few details and your glow is on its way.</p>

      <form onSubmit={handleSubmit} className="mt-10 grid gap-10 lg:grid-cols-[1fr_380px] lg:gap-14">
        <div className="space-y-8">
          <section className="rounded-[1.5rem] border border-[#e9e0d8] bg-white p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <span className="grid h-8 w-8 place-items-center rounded-full bg-[#2d2420] text-xs font-bold text-white">1</span>
              <h2 className="font-display text-2xl">Contact information</h2>
            </div>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <label className="sm:col-span-2">
                <span className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.14em] text-[#8a7c73]">Full name *</span>
                <input required value={form.customerName} onChange={update("customerName")} className="w-full rounded-xl border border-[#e5dad1] bg-[#fffcf8] px-4 py-3 text-sm outline-none focus:border-[#b47c6f]" placeholder="Amelia Rose" />
              </label>
              <label>
                <span className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.14em] text-[#8a7c73]">Email *</span>
                <input required type="email" value={form.email} onChange={update("email")} className="w-full rounded-xl border border-[#e5dad1] bg-[#fffcf8] px-4 py-3 text-sm outline-none focus:border-[#b47c6f]" placeholder="you@example.com" />
              </label>
              <label>
                <span className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.14em] text-[#8a7c73]">Phone</span>
                <input type="tel" value={form.phone} onChange={update("phone")} className="w-full rounded-xl border border-[#e5dad1] bg-[#fffcf8] px-4 py-3 text-sm outline-none focus:border-[#b47c6f]" placeholder="(555) 000-0000" />
              </label>
            </div>
          </section>

          <section className="rounded-[1.5rem] border border-[#e9e0d8] bg-white p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <span className="grid h-8 w-8 place-items-center rounded-full bg-[#2d2420] text-xs font-bold text-white">2</span>
              <h2 className="font-display text-2xl">Delivery address</h2>
            </div>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <label className="sm:col-span-2">
                <span className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.14em] text-[#8a7c73]">Street address *</span>
                <input required value={form.address} onChange={update("address")} className="w-full rounded-xl border border-[#e5dad1] bg-[#fffcf8] px-4 py-3 text-sm outline-none focus:border-[#b47c6f]" placeholder="18 Rose Lane, Apt 2" />
              </label>
              <label>
                <span className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.14em] text-[#8a7c73]">City *</span>
                <input required value={form.city} onChange={update("city")} className="w-full rounded-xl border border-[#e5dad1] bg-[#fffcf8] px-4 py-3 text-sm outline-none focus:border-[#b47c6f]" placeholder="New York" />
              </label>
              <label>
                <span className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.14em] text-[#8a7c73]">Postal code *</span>
                <input required value={form.postalCode} onChange={update("postalCode")} className="w-full rounded-xl border border-[#e5dad1] bg-[#fffcf8] px-4 py-3 text-sm outline-none focus:border-[#b47c6f]" placeholder="10001" />
              </label>
              <label className="sm:col-span-2">
                <span className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.14em] text-[#8a7c73]">Country *</span>
                <select required value={form.country} onChange={update("country")} className="w-full rounded-xl border border-[#e5dad1] bg-[#fffcf8] px-4 py-3 text-sm outline-none focus:border-[#b47c6f]">
                  <option>United States</option><option>Canada</option><option>United Kingdom</option><option>Australia</option><option>Other</option>
                </select>
              </label>
              <label className="sm:col-span-2">
                <span className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.14em] text-[#8a7c73]">Delivery note (optional)</span>
                <textarea rows={3} value={form.notes} onChange={update("notes")} className="w-full resize-none rounded-xl border border-[#e5dad1] bg-[#fffcf8] px-4 py-3 text-sm outline-none focus:border-[#b47c6f]" placeholder="Leave at the front desk" />
              </label>
            </div>
          </section>

          <section className="rounded-[1.5rem] border border-[#e9e0d8] bg-white p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <span className="grid h-8 w-8 place-items-center rounded-full bg-[#2d2420] text-xs font-bold text-white">3</span>
              <h2 className="font-display text-2xl">Payment</h2>
            </div>
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              {[
                { id: "card", label: "Card on delivery", sub: "Demo payment method" },
                { id: "cod", label: "Cash on delivery", sub: "Pay when it arrives" },
              ].map((option) => (
                <label key={option.id} className={`flex cursor-pointer items-center gap-3 rounded-xl border p-4 transition ${paymentMethod === option.id ? "border-[#b47c6f] bg-[#fbf3ef]" : "border-[#e5dad1]"}`}>
                  <input type="radio" name="paymentMethod" value={option.id} checked={paymentMethod === option.id} onChange={() => setPaymentMethod(option.id)} className="accent-[#b47c6f]" />
                  <span>
                    <span className="block text-sm font-semibold text-[#3b2c28]">{option.label}</span>
                    <span className="mt-0.5 block text-xs text-[#9c8d83]">{option.sub}</span>
                  </span>
                </label>
              ))}
            </div>
            <p className="mt-5 flex items-start gap-2 rounded-xl bg-[#f7f0ea] px-4 py-3 text-xs leading-5 text-[#796e67]">
              <ShieldCheck size={16} className="mt-0.5 shrink-0 text-[#9daa89]" />
              This is a demonstration storefront. No card details are collected, stored or charged.
            </p>
          </section>
        </div>

        <aside className="h-fit rounded-[1.5rem] border border-[#e9e0d8] bg-white p-6 lg:sticky lg:top-32">
          <h2 className="font-display text-2xl">Your order</h2>
          <div className="mt-5 max-h-64 space-y-4 overflow-y-auto pr-1">
            {items.map((item) => (
              <div key={item.id} className="flex gap-3">
                <div className="relative h-16 w-14 shrink-0 overflow-hidden rounded-lg bg-[#f0e8e1]">
                  <img src={item.imageUrl} alt={item.name} className="h-full w-full object-cover" />
                  <span className="absolute right-0 top-0 grid h-5 min-w-5 place-items-center rounded-bl-lg bg-[#2d2420] px-1 text-[10px] font-bold text-white">{item.quantity}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-[#3b2c28]">{item.name}</p>
                  <p className="mt-1 text-xs text-[#9c8d83]">{item.brand}</p>
                </div>
                <span className="text-sm font-semibold text-[#2d2420]">{formatPrice(item.priceCents * item.quantity)}</span>
              </div>
            ))}
          </div>
          <div className="mt-6 space-y-3 border-t border-[#eee5dd] pt-5 text-sm">
            <div className="flex justify-between text-[#796e67]"><span>Subtotal</span><span>{formatPrice(subtotal)}</span></div>
            <div className="flex justify-between text-[#796e67]"><span>Shipping</span><span>{shipping === 0 ? "Complimentary" : formatPrice(shipping)}</span></div>
            <div className="font-display flex justify-between border-t border-[#eee5dd] pt-4 text-2xl text-[#2d2420]"><span>Total</span><span>{formatPrice(total)}</span></div>
          </div>

          {error && (
            <p role="alert" className="mt-5 rounded-xl bg-[#fff0ec] px-4 py-3 text-xs leading-5 text-[#a04f45]">{error}</p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-[#2d2420] py-4 text-xs font-semibold uppercase tracking-[0.16em] text-white transition hover:bg-[#b47c6f] disabled:opacity-60"
          >
            {submitting ? <><Loader2 size={16} className="animate-spin" /> Placing order…</> : <><Check size={16} /> Place order</>}
          </button>
          <p className="mt-4 text-center text-[11px] leading-5 text-[#9c8d83]">By placing your order you agree to our demo terms and return policy.</p>
        </aside>
      </form>
    </div>
  );
}
