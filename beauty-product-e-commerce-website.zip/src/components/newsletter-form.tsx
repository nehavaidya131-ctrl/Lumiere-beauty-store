"use client";

import { ArrowRight, Check, Loader2 } from "lucide-react";
import { useState, type FormEvent } from "react";

export function NewsletterForm() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("loading");
    try {
      const response = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = (await response.json()) as { message?: string };
      if (!response.ok) throw new Error(data.message ?? "Something went wrong.");
      setStatus("success");
      setMessage("Welcome to the glow list. Check your inbox for a little treat.");
      setEmail("");
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "Please try again.");
    }
  }

  return (
    <div>
      <form onSubmit={handleSubmit} className="flex max-w-md items-center rounded-full border border-white/35 bg-white/10 p-1.5 backdrop-blur-sm">
        <input
          type="email"
          required
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          placeholder="Your email address"
          aria-label="Email address for newsletter"
          className="min-w-0 flex-1 bg-transparent px-4 text-sm text-white outline-none placeholder:text-white/70"
        />
        <button
          type="submit"
          disabled={status === "loading"}
          aria-label="Subscribe to newsletter"
          className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-white text-[#a9605b] transition hover:bg-[#f8e8e2] disabled:opacity-60"
        >
          {status === "loading" ? (
            <Loader2 size={17} className="animate-spin" />
          ) : status === "success" ? (
            <Check size={17} />
          ) : (
            <ArrowRight size={17} />
          )}
        </button>
      </form>
      {message && (
        <p className={`mt-3 text-xs ${status === "error" ? "text-[#ffe0d6]" : "text-white/90"}`}>
          {message}
        </p>
      )}
    </div>
  );
}
