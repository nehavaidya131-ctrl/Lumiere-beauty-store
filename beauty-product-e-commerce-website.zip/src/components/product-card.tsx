import Link from "next/link";
import { Star } from "lucide-react";

import { AddToCartButton } from "@/components/add-to-cart-button";
import { formatPrice, formatRating } from "@/lib/format";
import type { Product } from "@/lib/types";

export function ProductCard({ product }: { product: Product }) {
  return (
    <article className="group">
      <div className="relative aspect-[4/5] overflow-hidden rounded-[1.4rem] bg-[#f0e8e1]">
        <Link href={`/product/${product.slug}`} aria-label={`View ${product.name}`}>
          <img
            src={product.imageUrl}
            alt={product.name}
            loading="lazy"
            className="h-full w-full object-cover transition duration-700 ease-out group-hover:scale-[1.06]"
          />
        </Link>

        <div className="pointer-events-none absolute left-4 top-4 flex flex-col items-start gap-2">
          {product.badge && (
            <span className="rounded-full bg-[#fffcf8]/95 px-3 py-1.5 text-[9px] font-bold uppercase tracking-[0.16em] text-[#a9605b] shadow-sm">
              {product.badge}
            </span>
          )}
          {product.compareAtCents && product.compareAtCents > product.priceCents && (
            <span className="rounded-full bg-[#3b2c28]/90 px-3 py-1.5 text-[9px] font-bold uppercase tracking-[0.16em] text-white">
              Save {Math.round((1 - product.priceCents / product.compareAtCents) * 100)}%
            </span>
          )}
        </div>

        <div className="absolute inset-x-3 bottom-3 opacity-100 transition duration-300 lg:translate-y-2 lg:opacity-0 lg:group-hover:translate-y-0 lg:group-hover:opacity-100">
          <AddToCartButton
            product={product}
            className="w-full bg-[#fffcf8]/95 py-3 text-[#2d2420] shadow-lg backdrop-blur-sm hover:bg-[#2d2420] hover:text-white"
          />
        </div>
      </div>

      <div className="px-1 pt-4">
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#aa9b91]">
          {product.brand}
        </p>
        <Link
          href={`/product/${product.slug}`}
          className="font-display mt-1.5 block text-xl leading-snug text-[#2d2420] transition hover:text-[#b47c6f]"
        >
          {product.name}
        </Link>
        <div className="mt-2.5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-[#2d2420]">
              {formatPrice(product.priceCents)}
            </span>
            {product.compareAtCents && product.compareAtCents > product.priceCents && (
              <span className="text-xs text-[#ad9e94] line-through">
                {formatPrice(product.compareAtCents)}
              </span>
            )}
          </div>
          <span className="flex items-center gap-1 text-xs text-[#8f8178]">
            <Star size={12} className="fill-[#c79a62] text-[#c79a62]" />
            {formatRating(product.rating)} <span className="text-[#b5a89f]">({product.reviewCount})</span>
          </span>
        </div>
      </div>
    </article>
  );
}
