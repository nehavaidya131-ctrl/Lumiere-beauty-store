import type { Product } from "@/lib/types";

export type ProductSeed = Omit<Product, "id">;

const px = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800`;

export const seedProducts: ProductSeed[] = [
  {
    slug: "glowdrop-vitamin-c-serum",
    name: "Glowdrop Vitamin C Serum",
    brand: "Lumière Lab",
    category: "Skincare",
    description:
      "A weightless brightening serum that awakens dull skin with stabilized vitamin C, niacinamide and hyaluronic acid.",
    details:
      "This silky daily concentrate helps visibly even tone, soften the look of dark spots and leave skin with a fresh, luminous finish. Encapsulated actives keep the formula gentle enough for morning and evening rituals.",
    ingredients:
      "Aqua, 15% Tetrahexyldecyl Ascorbate, Niacinamide, Sodium Hyaluronate, Glycerin, Squalane, Panthenol, Tocopherol.",
    howToUse:
      "Apply 2–3 drops to clean, slightly damp skin before moisturizer. Follow with SPF in the morning.",
    priceCents: 4200,
    compareAtCents: 5200,
    imageUrl: px(7797735),
    badge: "Bestseller",
    stock: 48,
    rating: 49,
    reviewCount: 328,
    featured: true,
  },
  {
    slug: "cloud-veil-barrier-cream",
    name: "Cloud Veil Barrier Cream",
    brand: "Lumière Lab",
    category: "Skincare",
    description:
      "A cushiony ceramide moisturizer that wraps sensitive skin in lasting comfort without a heavy finish.",
    details:
      "A restorative blend of ceramides, cholesterol and fatty acids supports the moisture barrier while oat extract calms the feeling of tightness. Skin feels plush, calm and quietly dewy.",
    ingredients:
      "Aqua, Glycerin, Ceramide NP, Ceramide AP, Squalane, Colloidal Oatmeal, Allantoin, Shea Butter.",
    howToUse:
      "Massage a pearl-sized amount over face and neck as the final step in your skincare routine.",
    priceCents: 3800,
    compareAtCents: null,
    imageUrl: px(9775406),
    badge: null,
    stock: 36,
    rating: 48,
    reviewCount: 214,
    featured: true,
  },
  {
    slug: "midnight-repair-face-oil",
    name: "Midnight Repair Face Oil",
    brand: "Botanique No. 9",
    category: "Skincare",
    description:
      "A replenishing overnight botanical oil with rosehip, squalane and bakuchiol for a softer morning glow.",
    details:
      "This fast-absorbing golden oil seals in hydration and supports the look of firmness while you rest. A delicate lavender and neroli aroma turns your final skincare step into a nightly ritual.",
    ingredients:
      "Rosa Canina Seed Oil, Squalane, Bakuchiol, Jojoba Oil, Vitamin E, Lavender Oil, Neroli Oil.",
    howToUse:
      "Warm 3–4 drops between palms and press into skin after serum, before or in place of moisturizer.",
    priceCents: 5400,
    compareAtCents: null,
    imageUrl: px(7797453),
    badge: "New",
    stock: 27,
    rating: 49,
    reviewCount: 96,
    featured: true,
  },
  {
    slug: "dew-essence-hydrating-toner",
    name: "Dew Essence Hydrating Toner",
    brand: "Lumière Lab",
    category: "Skincare",
    description:
      "A milky, alcohol-free essence that floods skin with layers of hydration and preps it for actives.",
    details:
      "Five molecular weights of hyaluronic acid and beta-glucan give skin a bouncy, comfortable feel. Use it as a toner or layer it for a glass-skin finish.",
    ingredients:
      "Aqua, Sodium Hyaluronate, Beta-Glucan, Panthenol, Rice Bran Extract, Glycerin, Allantoin.",
    howToUse:
      "Pat into clean skin with your hands, then follow with serum while skin is still damp.",
    priceCents: 2900,
    compareAtCents: null,
    imageUrl: px(6767761),
    badge: null,
    stock: 54,
    rating: 47,
    reviewCount: 143,
    featured: false,
  },
  {
    slug: "reset-gentle-gel-cleanser",
    name: "Reset Gentle Gel Cleanser",
    brand: "Lumière Lab",
    category: "Skincare",
    description:
      "A low-foaming amino acid cleanser that removes sunscreen and impurities without stripping skin.",
    details:
      "The pH-balanced gel transforms into a soft lather and rinses clean, leaving the complexion fresh, balanced and ready for the rest of your routine.",
    ingredients:
      "Aqua, Sodium Cocoyl Glutamate, Glycerin, Cocamidopropyl Betaine, Aloe Vera, Panthenol.",
    howToUse:
      "Massage one pump onto damp skin for 30 seconds, then rinse with lukewarm water.",
    priceCents: 2600,
    compareAtCents: null,
    imageUrl: px(8101534),
    badge: null,
    stock: 62,
    rating: 48,
    reviewCount: 187,
    featured: false,
  },
  {
    slug: "mineral-veil-spf-40",
    name: "Mineral Veil SPF 40",
    brand: "Lumière Lab",
    category: "Skincare",
    description:
      "A sheer mineral sunscreen with a satin finish and no chalky cast, made for everyday wear.",
    details:
      "Non-nano zinc oxide provides broad-spectrum protection while niacinamide and vitamin E support a calm, even-looking complexion. Beautiful under makeup.",
    ingredients:
      "Zinc Oxide 12%, Aqua, Caprylic/Capric Triglyceride, Niacinamide, Glycerin, Tocopherol.",
    howToUse:
      "Apply generously as the last morning skincare step, at least 15 minutes before sun exposure.",
    priceCents: 3400,
    compareAtCents: null,
    imageUrl: px(7670764),
    badge: "Clean SPF",
    stock: 41,
    rating: 46,
    reviewCount: 121,
    featured: false,
  },
  {
    slug: "petal-silk-matte-lipstick",
    name: "Petal Silk Matte Lipstick",
    brand: "Maison Rose",
    category: "Makeup",
    description:
      "A featherlight, buildable matte lip color in a universally flattering soft rose.",
    details:
      "The creamy formula glides on with blurred, velvety pigment and a comfortable cushion feel, thanks to mango butter and hydrating squalane.",
    ingredients:
      "Ricinus Communis Seed Oil, Squalane, Mango Seed Butter, Silica, Candelilla Wax, Tocopherol.",
    howToUse:
      "Swipe from the cupid's bow outward. Blot once for a soft-focus stain or layer for full color.",
    priceCents: 2400,
    compareAtCents: 2800,
    imageUrl: px(7256154),
    badge: "Bestseller",
    stock: 75,
    rating: 48,
    reviewCount: 402,
    featured: true,
  },
  {
    slug: "soft-focus-eyeshadow-palette",
    name: "Soft Focus Eyeshadow Palette",
    brand: "Maison Rose",
    category: "Makeup",
    description:
      "Eight blendable neutrals in matte, satin and luminous shimmer finishes for effortless definition.",
    details:
      "Finely milled pigments deliver smooth payoff with minimal fallout. The curated rose-neutral wardrobe moves easily from a sheer daytime wash to a smoky evening eye.",
    ingredients:
      "Mica, Kaolin, Magnesium Stearate, Squalane, Silica, Tocopherol, Iron Oxides.",
    howToUse:
      "Build lighter shades through the crease, then press shimmer onto the lid with a fingertip.",
    priceCents: 4600,
    compareAtCents: null,
    imageUrl: px(2536009),
    badge: null,
    stock: 33,
    rating: 47,
    reviewCount: 168,
    featured: false,
  },
  {
    slug: "blush-bloom-cream-blush",
    name: "Blush Bloom Cream Blush",
    brand: "Maison Rose",
    category: "Makeup",
    description:
      "A translucent cream blush that melts into skin for a fresh, lit-from-within flush.",
    details:
      "The balmy, buildable texture blends seamlessly with fingers or a brush and leaves a natural satin finish that never looks powdery.",
    ingredients:
      "Caprylic/Capric Triglyceride, Jojoba Esters, Shea Butter, Squalane, Vitamin E, Mica.",
    howToUse:
      "Tap a small amount onto the apples of the cheeks and blend upward toward the temples.",
    priceCents: 2800,
    compareAtCents: null,
    imageUrl: px(27695994),
    badge: "New",
    stock: 58,
    rating: 48,
    reviewCount: 89,
    featured: false,
  },
  {
    slug: "fleur-de-nuit-eau-de-parfum",
    name: "Fleur de Nuit Eau de Parfum",
    brand: "Atelier Lumière",
    category: "Fragrance",
    description:
      "A modern floral wrapped in pink pepper, soft peony and warm skin-like musk.",
    details:
      "Fleur de Nuit opens bright and lightly spicy, settles into a petal-soft heart, then lingers with an intimate amber-musk trail. Understated, memorable and made for everyday elegance.",
    ingredients:
      "Alcohol Denat., Parfum, Aqua, Linalool, Limonene, Geraniol, Citronellol.",
    howToUse:
      "Spray once or twice onto pulse points. Avoid rubbing to preserve the top notes.",
    priceCents: 8800,
    compareAtCents: null,
    imageUrl: px(13875786),
    badge: "Signature",
    stock: 22,
    rating: 49,
    reviewCount: 231,
    featured: true,
  },
  {
    slug: "white-linen-eau-de-parfum",
    name: "White Linen Eau de Parfum",
    brand: "Atelier Lumière",
    category: "Fragrance",
    description:
      "An airy skin scent of clean cotton, white tea and soft cedar that feels like fresh sheets.",
    details:
      "Minimal and quietly addictive, this fragrance stays close to the skin and layers beautifully with any of the Atelier Lumière scents.",
    ingredients:
      "Alcohol Denat., Parfum, Aqua, Linalool, Citral, Coumarin.",
    howToUse:
      "Mist over clothing and pulse points, or layer with Fleur de Nuit for a softer floral finish.",
    priceCents: 7800,
    compareAtCents: null,
    imageUrl: px(27357173),
    badge: null,
    stock: 18,
    rating: 47,
    reviewCount: 104,
    featured: false,
  },
  {
    slug: "golden-hour-body-oil",
    name: "Golden Hour Body Oil",
    brand: "Botanique No. 9",
    category: "Body",
    description:
      "A fast-absorbing body oil that leaves skin satin-soft with a subtle golden sheen.",
    details:
      "A nourishing blend of camelina, marula and sunflower oils restores suppleness after bathing while a delicate warm citrus scent lingers on skin.",
    ingredients:
      "Helianthus Annuus Seed Oil, Camelina Sativa Seed Oil, Sclerocarya Birrea Seed Oil, Vitamin E, Citrus Extract.",
    howToUse:
      "Smooth over damp skin after a shower, or add a few drops to body lotion.",
    priceCents: 4200,
    compareAtCents: null,
    imageUrl: px(12146904),
    badge: null,
    stock: 44,
    rating: 48,
    reviewCount: 152,
    featured: false,
  },
];
