import { db } from "@/db";
import { orderItems, orders, products } from "@/db/schema";
import {
  and,
  asc,
  count,
  desc,
  eq,
  gte,
  ilike,
  inArray,
  lte,
  ne,
  or,
} from "drizzle-orm";

import { seedProducts } from "@/lib/seed-data";
import type { OrderRecord, Product, ProductFilters } from "@/lib/types";

let seedPromise: Promise<void> | null = null;

export async function ensureSeeded() {
  if (!seedPromise) {
    seedPromise = (async () => {
      const [result] = await db.select({ value: count() }).from(products);
      if (Number(result.value) === 0) {
        await db.insert(products).values(seedProducts).onConflictDoNothing();
      }
    })().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

export async function getProducts(filters: ProductFilters = {}): Promise<Product[]> {
  await ensureSeeded();

  const conditions = [];
  if (filters.category) {
    conditions.push(eq(products.category, filters.category));
  }
  if (filters.q) {
    const term = `%${filters.q}%`;
    const search = or(
      ilike(products.name, term),
      ilike(products.brand, term),
      ilike(products.description, term),
      ilike(products.category, term),
    );
    if (search) conditions.push(search);
  }
  if (typeof filters.maxPrice === "number" && Number.isFinite(filters.maxPrice)) {
    conditions.push(lte(products.priceCents, Math.round(filters.maxPrice * 100)));
  }

  const orderBy =
    filters.sort === "price-low"
      ? [asc(products.priceCents)]
      : filters.sort === "price-high"
        ? [desc(products.priceCents)]
        : filters.sort === "newest"
          ? [desc(products.createdAt)]
          : filters.sort === "rating"
            ? [desc(products.rating), desc(products.reviewCount)]
            : [desc(products.featured), desc(products.rating)];

  const rows = await db
    .select()
    .from(products)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(...orderBy);

  return rows as Product[];
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  await ensureSeeded();
  const [row] = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  return (row as Product | undefined) ?? null;
}

export async function getFeaturedProducts(limit = 4): Promise<Product[]> {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(products)
    .where(eq(products.featured, true))
    .orderBy(desc(products.rating))
    .limit(limit);
  return rows as Product[];
}

export async function getRelatedProducts(product: Product, limit = 4): Promise<Product[]> {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(products)
    .where(and(eq(products.category, product.category), ne(products.id, product.id)))
    .limit(limit);
  return rows as Product[];
}

export async function getCategories(): Promise<string[]> {
  const rows = await getProducts();
  return ["Skincare", "Makeup", "Fragrance", "Body"].filter((category) =>
    rows.some((product) => product.category === category),
  );
}

export async function getOrderByNumber(orderNumber: string): Promise<OrderRecord | null> {
  await ensureSeeded();
  const [order] = await db
    .select()
    .from(orders)
    .where(eq(orders.orderNumber, orderNumber))
    .limit(1);
  if (!order) return null;

  const items = await db
    .select()
    .from(orderItems)
    .where(eq(orderItems.orderId, order.id));

  return {
    ...order,
    createdAt: order.createdAt.toISOString(),
    items,
  };
}

export async function getOrders(): Promise<OrderRecord[]> {
  await ensureSeeded();
  const allOrders = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(100);
  const ids = allOrders.map((order) => order.id);
  const items = ids.length
    ? await db.select().from(orderItems).where(inArray(orderItems.orderId, ids))
    : [];

  return allOrders.map((order) => ({
    ...order,
    createdAt: order.createdAt.toISOString(),
    items: items.filter((item) => item.orderId === order.id),
  }));
}

export async function getLowStockProducts(): Promise<Product[]> {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(products)
    .where(lte(products.stock, 10))
    .orderBy(asc(products.stock));
  return rows as Product[];
}

export async function getInStockCount() {
  await ensureSeeded();
  const [row] = await db
    .select({ value: count() })
    .from(products)
    .where(gte(products.stock, 1));
  return Number(row.value);
}
