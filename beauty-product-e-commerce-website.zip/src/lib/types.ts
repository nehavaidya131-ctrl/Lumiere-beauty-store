export interface Product {
  id: number;
  slug: string;
  name: string;
  brand: string;
  category: string;
  description: string;
  details: string;
  ingredients: string;
  howToUse: string;
  priceCents: number;
  compareAtCents: number | null;
  imageUrl: string;
  badge: string | null;
  stock: number;
  rating: number;
  reviewCount: number;
  featured: boolean;
}

export interface CartItem {
  id: number;
  slug: string;
  name: string;
  brand: string;
  imageUrl: string;
  priceCents: number;
  quantity: number;
}

export interface ProductFilters {
  category?: string;
  q?: string;
  maxPrice?: number;
  sort?: "featured" | "price-low" | "price-high" | "newest" | "rating";
}

export interface OrderItemRecord {
  id: number;
  productId: number;
  name: string;
  imageUrl: string;
  unitPriceCents: number;
  quantity: number;
}

export interface OrderRecord {
  id: number;
  orderNumber: string;
  customerName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  postalCode: string;
  country: string;
  subtotalCents: number;
  shippingCents: number;
  totalCents: number;
  status: string;
  createdAt: string;
  items: OrderItemRecord[];
}

export const ORDER_STATUSES = [
  "pending",
  "paid",
  "processing",
  "shipped",
  "delivered",
  "cancelled",
] as const;

export const FREE_SHIPPING_CENTS = 5000;
export const STANDARD_SHIPPING_CENTS = 795;
