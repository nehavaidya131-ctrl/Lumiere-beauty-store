import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default function NotFound() {
  return (
    <div className="grid min-h-[60vh] place-items-center bg-[#fbf7f3] px-5 py-20 text-center">
      <div>
        <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-[#b47c6f]">404 · Off the beauty trail</p>
        <h1 className="font-display mt-4 text-5xl">We couldn&apos;t find that page</h1>
        <p className="mx-auto mt-4 max-w-md text-sm leading-6 text-[#796e67]">
          The product or page you are looking for may have moved. Let&apos;s get you back to something beautiful.
        </p>
        <Link href="/shop" className="mt-8 inline-flex items-center gap-2 rounded-full bg-[#2d2420] px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.15em] text-white hover:bg-[#b47c6f]">
          Shop the collection <ArrowRight size={15} />
        </Link>
      </div>
    </div>
  );
}
