import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, Check, Star } from "lucide-react";

import { ProductCard } from "@/components/product-card";
import { ProductPurchase } from "@/components/product-purchase";
import { getProductBySlug, getRelatedProducts } from "@/lib/catalog";
import { formatPrice, formatRating } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const related = await getRelatedProducts(product, 4);

  return (
    <>
      <div className="mx-auto max-w-[1400px] px-5 py-7 lg:px-10">
        <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-[#9c8d83]">
          <Link href="/" className="hover:text-[#b47c6f]">Home</Link>
          <span className="mx-2 text-[#cbb5a8]">/</span>
          <Link href="/shop" className="hover:text-[#b47c6f]">Shop</Link>
          <span className="mx-2 text-[#cbb5a8]">/</span>
          <Link href={`/shop?category=${encodeURIComponent(product.category)}`} className="hover:text-[#b47c6f]">
            {product.category}
          </Link>
        </p>
      </div>

      <section className="mx-auto grid max-w-[1400px] gap-10 px-5 pb-16 lg:grid-cols-2 lg:gap-16 lg:px-10 lg:pb-24">
        <div className="relative">
          <div className="overflow-hidden rounded-[1.6rem] bg-[#f0e8e1]">
            <img
              src={product.imageUrl}
              alt={product.name}
              className="aspect-[4/5] h-full w-full object-cover"
            />
          </div>
          <div className="absolute bottom-5 left-5 flex items-center gap-3 rounded-full border border-white/60 bg-white/90 px-4 py-2.5 backdrop-blur-sm">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-[#e8f0e5] text-[#76906f]">
              <Check size={15} />
            </span>
            <span className="text-[10px] font-semibold uppercase tracking-[0.14em] text-[#574c46]">
              Clean formula · Cruelty free
            </span>
          </div>
        </div>

        <div className="flex flex-col justify-center lg:py-6">
          <div className="flex flex-wrap items-center gap-3">
            <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-[#b47c6f]">{product.brand}</p>
            {product.badge && (
              <span className="rounded-full bg-[#f4e7e1] px-3 py-1 text-[9px] font-bold uppercase tracking-[0.14em] text-[#a9605b]">
                {product.badge}
              </span>
            )}
          </div>
          <h1 className="font-display mt-4 text-4xl leading-[1.06] sm:text-5xl">{product.name}</h1>
          <div className="mt-4 flex flex-wrap items-center gap-4">
            <span className="flex items-center gap-1 text-sm text-[#8f8178]">
              {[0, 1, 2, 3, 4].map((index) => (
                <Star key={index} size={13} className="fill-[#c79a62] text-[#c79a62]" />
              ))}
              <span className="ml-1 font-medium text-[#3b2c28]">{formatRating(product.rating)}</span>
              <span>({product.reviewCount} reviews)</span>
            </span>
            <span className="text-[11px] uppercase tracking-[0.14em] text-[#9daa89]">
              {product.stock > 10 ? "In stock" : product.stock > 0 ? `Only ${product.stock} left` : "Sold out"}
            </span>
          </div>

          <div className="mt-6 flex items-end gap-3">
            <span className="font-display text-4xl text-[#2d2420]">{formatPrice(product.priceCents)}</span>
            {product.compareAtCents && product.compareAtCents > product.priceCents && (
              <span className="mb-1 text-base text-[#ad9e94] line-through">{formatPrice(product.compareAtCents)}</span>
            )}
          </div>
          <p className="mt-6 max-w-xl text-sm leading-7 text-[#796e67]">{product.description}</p>

          <ProductPurchase product={product} />
        </div>
      </section>

      {related.length > 0 && (
        <section className="bg-[#f7f0ea] py-16 lg:py-20">
          <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
            <div className="flex items-end justify-between gap-4">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-[#b47c6f]">Complete the ritual</p>
                <h2 className="font-display mt-3 text-4xl">You may also love</h2>
              </div>
              <Link href={`/shop?category=${encodeURIComponent(product.category)}`} className="hidden items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-[#5c5049] hover:text-[#b47c6f] sm:flex">
                More {product.category} <ArrowRight size={15} />
              </Link>
            </div>
            <div className="mt-9 grid gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
              {related.map((item) => (
                <ProductCard key={item.id} product={item} />
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );
}
