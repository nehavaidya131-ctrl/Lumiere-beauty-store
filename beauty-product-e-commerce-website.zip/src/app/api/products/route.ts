import { db } from "@/db";
import { products } from "@/db/schema";

import { ensureSeeded, getProducts } from "@/lib/catalog";
import { slugify } from "@/lib/format";
import type { ProductFilters } from "@/lib/types";

export const dynamic = "force-dynamic";

const DEFAULT_IMAGE =
  "https://images.pexels.com/photos/7797735/pexels-photo-7797735.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800";

function cleanText(value: unknown, max = 1000) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const sort = url.searchParams.get("sort") ?? undefined;
    const validSort = ["featured", "price-low", "price-high", "newest", "rating"].includes(
      sort ?? "",
    )
      ? (sort as ProductFilters["sort"])
      : "featured";
    const category = url.searchParams.get("category") ?? undefined;
    const q = url.searchParams.get("q") ?? undefined;
    const maxPrice = Number(url.searchParams.get("maxPrice") ?? "");

    const result = await getProducts({
      category,
      q,
      maxPrice: Number.isFinite(maxPrice) && maxPrice > 0 ? maxPrice : undefined,
      sort: validSort,
    });
    return Response.json({ products: result, count: result.length });
  } catch (error) {
    console.error("Failed to fetch products", error);
    return Response.json({ message: "Could not load products." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    await ensureSeeded();
    const body = (await request.json().catch(() => null)) as Record<string, unknown> | null;
    if (!body) return Response.json({ message: "Invalid request." }, { status: 400 });

    const name = cleanText(body.name, 160);
    const price = Number(body.price);
    if (name.length < 2 || !Number.isFinite(price) || price <= 0) {
      return Response.json(
        { message: "A product name and a valid price are required." },
        { status: 400 },
      );
    }

    const description =
      cleanText(body.description) || "A new beauty essential from Lumière Beauty Studio.";
    const imageUrl = cleanText(body.imageUrl, 1000) || DEFAULT_IMAGE;
    const brand = cleanText(body.brand, 120) || "Lumière Lab";
    const allowedCategories = ["Skincare", "Makeup", "Fragrance", "Body"];
    const category = allowedCategories.includes(cleanText(body.category))
      ? cleanText(body.category)
      : "Skincare";
    const stockValue = Number(body.stock ?? 30);
    const stock = Number.isInteger(stockValue) && stockValue >= 0 ? stockValue : 30;
    const badge = cleanText(body.badge, 60) || null;
    const slug = `${slugify(name) || "beauty-product"}-${Date.now().toString(36)}`;

    const [created] = await db
      .insert(products)
      .values({
        slug,
        name,
        brand,
        category,
        description,
        details: description,
        ingredients: "Ingredient details will be added soon.",
        howToUse: "Apply as part of your daily beauty ritual.",
        priceCents: Math.round(price * 100),
        compareAtCents: null,
        imageUrl,
        badge,
        stock,
        rating: 48,
        reviewCount: 0,
        featured: false,
      })
      .returning();

    return Response.json({ product: created }, { status: 201 });
  } catch (error) {
    console.error("Failed to create product", error);
    return Response.json({ message: "Could not add product." }, { status: 500 });
  }
}
