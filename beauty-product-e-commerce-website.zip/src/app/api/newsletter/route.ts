import { db } from "@/db";
import { subscribers } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as { email?: unknown } | null;
  const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    return Response.json({ message: "Please enter a valid email address." }, { status: 400 });
  }

  try {
    await db.insert(subscribers).values({ email }).onConflictDoNothing();
    return Response.json({ message: "You're on the list. Welcome to Lumière!" }, { status: 201 });
  } catch (error) {
    console.error("Failed to save subscriber", error);
    return Response.json({ message: "Could not subscribe right now." }, { status: 500 });
  }
}
