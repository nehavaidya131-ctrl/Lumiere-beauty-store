import { ensureSeeded, getProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();
    const products = await getProducts();
    return Response.json({ ok: true, products: products.length });
  } catch (error) {
    console.error("Failed to seed catalog", error);
    return Response.json({ ok: false, message: "Catalog setup failed." }, { status: 500 });
  }
}
