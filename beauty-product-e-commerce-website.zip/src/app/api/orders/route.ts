import { db } from "@/db";
import { orderItems, orders, products } from "@/db/schema";
import { and, eq, gte, inArray, sql } from "drizzle-orm";

import { ensureSeeded, getOrders } from "@/lib/catalog";
import {
  FREE_SHIPPING_CENTS,
  STANDARD_SHIPPING_CENTS,
} from "@/lib/types";

export const dynamic = "force-dynamic";

function cleanText(value: unknown) {
  return typeof value === "string" ? value.trim().slice(0, 500) : "";
}

interface RequestedItem {
  productId: number;
  quantity: number;
}

function normalizeItems(value: unknown): RequestedItem[] {
  if (!Array.isArray(value)) return [];
  const combined = new Map<number, number>();
  for (const raw of value) {
    if (!raw || typeof raw !== "object") continue;
    const item = raw as Record<string, unknown>;
    const productId = Number(item.productId);
    const quantity = Number(item.quantity);
    if (!Number.isInteger(productId) || productId <= 0) continue;
    if (!Number.isInteger(quantity) || quantity <= 0) continue;
    combined.set(productId, Math.min(20, (combined.get(productId) ?? 0) + quantity));
  }
  return Array.from(combined, ([productId, quantity]) => ({ productId, quantity }));
}

export async function GET() {
  try {
    return Response.json({ orders: await getOrders() });
  } catch (error) {
    console.error("Failed to fetch orders", error);
    return Response.json({ message: "Could not load orders." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    await ensureSeeded();
    const body = (await request.json().catch(() => null)) as Record<string, unknown> | null;
    if (!body) return Response.json({ message: "Invalid request." }, { status: 400 });

    const customerName = cleanText(body.customerName);
    const email = cleanText(body.email);
    const phone = cleanText(body.phone);
    const address = cleanText(body.address);
    const city = cleanText(body.city);
    const postalCode = cleanText(body.postalCode);
    const country = cleanText(body.country) || "United States";
    const requestedItems = normalizeItems(body.items);

    if (requestedItems.length === 0) {
      return Response.json({ message: "Your bag is empty." }, { status: 400 });
    }
    if (
      customerName.length < 2 ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
      !address ||
      !city ||
      !postalCode
    ) {
      return Response.json(
        { message: "Please complete all required contact and delivery fields." },
        { status: 400 },
      );
    }

    const orderNumber = `LUM-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;

    const created = await db.transaction(async (tx) => {
      const ids = requestedItems.map((item) => item.productId);
      const available = await tx
        .select()
        .from(products)
        .where(inArray(products.id, ids));
      const productMap = new Map(available.map((product) => [product.id, product]));

      const lines = requestedItems.map((item) => {
        const product = productMap.get(item.productId);
        if (!product) throw new Error("A selected product is no longer available.");
        if (product.stock < item.quantity) {
          throw new Error(`Insufficient stock for ${product.name}.`);
        }
        return {
          productId: product.id,
          name: product.name,
          imageUrl: product.imageUrl,
          unitPriceCents: product.priceCents,
          quantity: item.quantity,
        };
      });

      const subtotalCents = lines.reduce(
        (sum, line) => sum + line.unitPriceCents * line.quantity,
        0,
      );
      const shippingCents =
        subtotalCents >= FREE_SHIPPING_CENTS ? 0 : STANDARD_SHIPPING_CENTS;

      const [order] = await tx
        .insert(orders)
        .values({
          orderNumber,
          customerName,
          email,
          phone,
          address,
          city,
          postalCode,
          country,
          subtotalCents,
          shippingCents,
          totalCents: subtotalCents + shippingCents,
          status: "pending",
        })
        .returning({ id: orders.id, orderNumber: orders.orderNumber });

      for (const line of lines) {
        const updated = await tx
          .update(products)
          .set({ stock: sql`${products.stock} - ${line.quantity}` })
          .where(
            and(
              eq(products.id, line.productId),
              gte(products.stock, line.quantity),
            ),
          )
          .returning({ id: products.id });
        if (updated.length === 0) {
          throw new Error(`Insufficient stock for ${line.name}.`);
        }
        await tx.insert(orderItems).values({
          orderId: order.id,
          ...line,
        });
      }

      return order;
    });

    return Response.json(
      { orderNumber: created.orderNumber, id: created.id },
      { status: 201 },
    );
  } catch (error) {
    console.error("Failed to create order", error);
    const message =
      error instanceof Error ? error.message : "Could not place your order.";
    const status =
      message.includes("Insufficient stock") || message.includes("no longer available")
        ? 409
        : 500;
    return Response.json({ message }, { status });
  }
}
