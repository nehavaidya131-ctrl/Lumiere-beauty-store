import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";

import { ORDER_STATUSES } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function PATCH(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const { id: rawId } = await context.params;
  const id = Number(rawId);
  if (!Number.isInteger(id) || id <= 0) {
    return Response.json({ message: "Invalid order id." }, { status: 400 });
  }

  const body = (await request.json().catch(() => null)) as { status?: unknown } | null;
  const status = typeof body?.status === "string" ? body.status : "";
  if (!ORDER_STATUSES.includes(status as (typeof ORDER_STATUSES)[number])) {
    return Response.json({ message: "Invalid order status." }, { status: 400 });
  }

  try {
    const updated = await db
      .update(orders)
      .set({ status })
      .where(eq(orders.id, id))
      .returning({ id: orders.id, status: orders.status });

    if (updated.length === 0) {
      return Response.json({ message: "Order not found." }, { status: 404 });
    }
    return Response.json({ ok: true, order: updated[0] });
  } catch (error) {
    console.error("Failed to update order", error);
    return Response.json({ message: "Could not update order." }, { status: 500 });
  }
}
