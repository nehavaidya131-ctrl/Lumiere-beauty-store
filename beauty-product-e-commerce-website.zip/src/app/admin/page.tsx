import type { Metadata } from "next";

import { AdminDashboard } from "@/components/admin-dashboard";
import { getOrders, getProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Store Dashboard",
  description: "Manage Lumière Beauty orders and inventory.",
};

export default async function AdminPage() {
  const [orders, products] = await Promise.all([getOrders(), getProducts()]);
  const activeOrders = orders.filter((order) => order.status !== "cancelled");
  const revenue = activeOrders.reduce((sum, order) => sum + order.totalCents, 0);

  const stats = {
    revenue,
    orderCount: orders.length,
    average: orders.length ? Math.round(revenue / activeOrders.length || 0) : 0,
    productCount: products.length,
    lowStock: products.filter((product) => product.stock <= 10).length,
  };

  return (
    <div className="bg-[#fbf7f3]">
      <div className="mx-auto max-w-[1400px] px-5 py-12 lg:px-10 lg:py-16">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-[#b47c6f]">Lumière back office</p>
            <h1 className="font-display mt-3 text-5xl">Store Dashboard</h1>
            <p className="mt-3 max-w-xl text-sm leading-6 text-[#796e67]">
              A live view of orders, revenue and inventory. This demo dashboard is intentionally open so you can explore the backend quickly.
            </p>
          </div>
          <div className="rounded-full border border-[#e2d7ce] bg-white px-4 py-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-[#8a7c73]">
            Average order · {stats.average / 100 ? `$${(stats.average / 100).toFixed(2)}` : "$0.00"}
          </div>
        </div>

        <div className="mt-10">
          <AdminDashboard orders={orders} products={products} stats={stats} />
        </div>
      </div>
    </div>
  );
}
