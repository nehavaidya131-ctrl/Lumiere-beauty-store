import type { Metadata } from "next";
import type { ReactNode } from "react";

import "./globals.css";
import { CartProvider } from "@/components/cart-provider";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";

export const metadata: Metadata = {
  title: {
    default: "Lumière Beauty | Clean Beauty, Quiet Luxury",
    template: "%s | Lumière Beauty",
  },
  description:
    "Shop considered skincare, makeup, fragrance and body essentials from Lumière Beauty Studio.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#fffcf8] text-[#2d2420] antialiased">
        <CartProvider>
          <SiteHeader />
          <main className="min-h-[60vh]">{children}</main>
          <SiteFooter />
        </CartProvider>
      </body>
    </html>
  );
}
