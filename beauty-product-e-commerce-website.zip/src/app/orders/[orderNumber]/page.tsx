import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, CheckCircle2, Mail, MapPin, Package } from "lucide-react";

import { getOrderByNumber } from "@/lib/catalog";
import { formatDate, formatPrice } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function OrderPage({
  params,
}: {
  params: Promise<{ orderNumber: string }>;
}) {
  const { orderNumber } = await params;
  const order = await getOrderByNumber(orderNumber);
  if (!order) notFound();

  return (
    <div className="mx-auto max-w-5xl px-5 py-12 lg:py-20">
      <div className="text-center">
        <div className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-[#e8f0e5] text-[#78906f]">
          <CheckCircle2 size={38} strokeWidth={1.5} />
        </div>
        <p className="mt-6 text-[10px] font-semibold uppercase tracking-[0.24em] text-[#b47c6f]">Order confirmed</p>
        <h1 className="font-display mt-3 text-4xl sm:text-5xl">Thank you, {order.customerName.split(" ")[0]}.</h1>
        <p className="mx-auto mt-4 max-w-lg text-sm leading-6 text-[#796e67]">
          Your little luxuries are being prepared with care. A confirmation has been sent to <strong className="text-[#3b2c28]">{order.email}</strong>.
        </p>
      </div>

      <div className="mt-10 grid gap-3 rounded-2xl border border-[#e9e0d8] bg-[#fbf7f3] p-5 text-center sm:grid-cols-3">
        <div><p className="text-[10px] uppercase tracking-[0.16em] text-[#9c8d83]">Order number</p><p className="mt-1 text-sm font-semibold text-[#2d2420]">{order.orderNumber}</p></div>
        <div><p className="text-[10px] uppercase tracking-[0.16em] text-[#9c8d83]">Order date</p><p className="mt-1 text-sm font-semibold text-[#2d2420]">{formatDate(order.createdAt)}</p></div>
        <div><p className="text-[10px] uppercase tracking-[0.16em] text-[#9c8d83]">Status</p><p className="mt-1 text-sm font-semibold capitalize text-[#a9605b]">{order.status}</p></div>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.4fr_0.9fr]">
        <section className="rounded-[1.5rem] border border-[#e9e0d8] bg-white p-6">
          <h2 className="font-display text-2xl">Order details</h2>
          <div className="mt-6 divide-y divide-[#eee5dd]">
            {order.items.map((item) => (
              <div key={item.id} className="flex items-center gap-4 py-4">
                <img src={item.imageUrl} alt={item.name} className="h-20 w-16 rounded-lg object-cover" />
                <div className="min-w-0 flex-1">
                  <p className="font-display text-lg text-[#2d2420]">{item.name}</p>
                  <p className="mt-1 text-xs text-[#9c8d83]">Quantity {item.quantity} · {formatPrice(item.unitPriceCents)} each</p>
                </div>
                <span className="text-sm font-semibold text-[#2d2420]">{formatPrice(item.unitPriceCents * item.quantity)}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 space-y-2 border-t border-[#e9e0d8] pt-5 text-sm">
            <div className="flex justify-between text-[#796e67]"><span>Subtotal</span><span>{formatPrice(order.subtotalCents)}</span></div>
            <div className="flex justify-between text-[#796e67]"><span>Shipping</span><span>{order.shippingCents === 0 ? "Complimentary" : formatPrice(order.shippingCents)}</span></div>
            <div className="font-display flex justify-between pt-2 text-2xl text-[#2d2420]"><span>Total paid</span><span>{formatPrice(order.totalCents)}</span></div>
          </div>
        </section>

        <div className="space-y-6">
          <section className="rounded-[1.5rem] border border-[#e9e0d8] bg-white p-6">
            <h2 className="flex items-center gap-2 font-display text-2xl"><MapPin size={19} className="text-[#b47c6f]" /> Delivery to</h2>
            <address className="mt-4 text-sm not-italic leading-6 text-[#796e67]">
              <strong className="text-[#3b2c28]">{order.customerName}</strong><br />
              {order.address}<br />{order.city}, {order.postalCode}<br />{order.country}
              {order.phone && <><br />{order.phone}</>}
            </address>
          </section>
          <section className="rounded-[1.5rem] bg-[#3b2c28] p-6 text-white">
            <Package size={22} className="text-[#d8b8aa]" />
            <h2 className="font-display mt-3 text-2xl">What happens next?</h2>
            <p className="mt-3 text-xs leading-6 text-white/75">We carefully pack your order within one business day. Standard delivery arrives in 3–5 business days.</p>
            <p className="mt-4 flex items-center gap-2 text-xs text-white/85"><Mail size={14} /> Questions? hello@lumierebeauty.com</p>
          </section>
        </div>
      </div>

      <div className="mt-10 text-center">
        <Link href="/shop" className="inline-flex items-center gap-2 rounded-full bg-[#2d2420] px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.15em] text-white transition hover:bg-[#b47c6f]">
          Continue shopping <ArrowRight size={15} />
        </Link>
      </div>
    </div>
  );
}
