import type { Metadata } from "next";

import { CheckoutForm } from "@/components/checkout-form";

export const metadata: Metadata = {
  title: "Checkout",
  description: "Complete your Lumière Beauty order.",
};

export default function CheckoutPage() {
  return <CheckoutForm />;
}
