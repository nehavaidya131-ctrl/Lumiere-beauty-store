"use client";

import Link from "next/link";
import { ArrowRight, Minus, Plus, ShoppingBag, Trash2, Truck } from "lucide-react";

import { useCart } from "@/components/cart-provider";
import { formatPrice } from "@/lib/format";
import { FREE_SHIPPING_CENTS } from "@/lib/types";

export default function CartPage() {
  const { items, hydrated, subtotal, shipping, total, setQuantity, removeItem, clearCart } = useCart();

  if (!hydrated) {
    return <div className="grid min-h-[50vh] place-items-center text-sm text-[#9c8d83]">Loading your bag…</div>;
  }

  const progress = Math.min(100, (subtotal / FREE_SHIPPING_CENTS) * 100);

  return (
    <div className="mx-auto max-w-[1400px] px-5 py-12 lg:px-10 lg:py-16">
      <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-[#b47c6f]">Your selection</p>
      <h1 className="font-display mt-3 text-5xl">Shopping Bag</h1>

      {items.length === 0 ? (
        <div className="mt-10 rounded-[1.5rem] border border-dashed border-[#ddcec3] bg-[#fbf7f3] px-8 py-20 text-center">
          <div className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-[#f4e7e1] text-[#b47c6f]">
            <ShoppingBag size={32} strokeWidth={1.3} />
          </div>
          <h2 className="font-display mt-6 text-3xl">Your bag is waiting</h2>
          <p className="mx-auto mt-3 max-w-md text-sm leading-6 text-[#796e67]">
            Explore thoughtful formulas and find a little everyday luxury to take home.
          </p>
          <Link href="/shop" className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#2d2420] px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.15em] text-white hover:bg-[#b47c6f]">
            Shop the collection <ArrowRight size={15} />
          </Link>
        </div>
      ) : (
        <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_360px] lg:gap-14">
          <div>
            <div className="mb-7 rounded-2xl bg-[#f7f0ea] px-5 py-4">
              <div className="flex items-center justify-between gap-3 text-xs text-[#6e5c53]">
                <span className="flex items-center gap-2">
                  <Truck size={16} className="text-[#b47c6f]" />
                  {shipping === 0
                    ? "You've unlocked complimentary shipping!"
                    : `Add ${formatPrice(FREE_SHIPPING_CENTS - subtotal)} for complimentary shipping`}
                </span>
                <span className="font-semibold">{Math.round(progress)}%</span>
              </div>
              <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-[#e7d9cf]">
                <div className="h-full rounded-full bg-[#b47c6f] transition-all" style={{ width: `${progress}%` }} />
              </div>
            </div>

            <div className="hidden grid-cols-[1fr_120px_100px_40px] gap-4 border-b border-[#e9e0d8] pb-3 text-[10px] font-semibold uppercase tracking-[0.16em] text-[#aa9b91] sm:grid">
              <span>Product</span><span className="text-center">Quantity</span><span className="text-right">Total</span><span />
            </div>

            <div className="divide-y divide-[#eee5dd]">
              {items.map((item) => (
                <div key={item.id} className="grid grid-cols-[100px_1fr] items-center gap-4 py-6 sm:grid-cols-[100px_1fr_120px_100px_40px]">
                  <Link href={`/product/${item.slug}`} className="h-28 w-24 overflow-hidden rounded-xl bg-[#f0e8e1]">
                    <img src={item.imageUrl} alt={item.name} className="h-full w-full object-cover" />
                  </Link>
                  <div>
                    <p className="text-[10px] uppercase tracking-[0.18em] text-[#aa9b91]">{item.brand}</p>
                    <Link href={`/product/${item.slug}`} className="font-display mt-1 block text-xl text-[#2d2420] hover:text-[#b47c6f]">
                      {item.name}
                    </Link>
                    <p className="mt-1 text-xs text-[#8a7c73]">{formatPrice(item.priceCents)} each</p>
                  </div>
                  <div className="mt-3 flex w-fit items-center rounded-full border border-[#e2d7ce] sm:mx-auto sm:mt-0">
                    <button type="button" onClick={() => setQuantity(item.id, item.quantity - 1)} aria-label={`Decrease ${item.name}`} className="grid h-9 w-9 place-items-center text-[#675a53]">
                      <Minus size={14} />
                    </button>
                    <span className="w-7 text-center text-sm">{item.quantity}</span>
                    <button type="button" onClick={() => setQuantity(item.id, item.quantity + 1)} aria-label={`Increase ${item.name}`} className="grid h-9 w-9 place-items-center text-[#675a53]">
                      <Plus size={14} />
                    </button>
                  </div>
                  <span className="hidden text-right text-sm font-semibold text-[#2d2420] sm:block">
                    {formatPrice(item.priceCents * item.quantity)}
                  </span>
                  <button type="button" onClick={() => removeItem(item.id)} aria-label={`Remove ${item.name}`} className="justify-self-end text-[#aa9b91] hover:text-[#b47c6f]">
                    <Trash2 size={17} />
                  </button>
                </div>
              ))}
            </div>

            <div className="mt-5 flex flex-wrap justify-between gap-3">
              <Link href="/shop" className="text-xs font-semibold uppercase tracking-[0.14em] text-[#796e67] underline underline-offset-4">
                Continue shopping
              </Link>
              <button type="button" onClick={clearCart} className="text-xs font-semibold uppercase tracking-[0.14em] text-[#a9605b] underline underline-offset-4">
                Clear bag
              </button>
            </div>
          </div>

          <aside className="h-fit rounded-[1.5rem] border border-[#e9e0d8] bg-white p-6 lg:sticky lg:top-32">
            <h2 className="font-display text-2xl">Order summary</h2>
            <div className="mt-6 space-y-3 text-sm">
              <div className="flex justify-between text-[#796e67]">
                <span>Subtotal</span><span>{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between text-[#796e67]">
                <span>Shipping</span><span>{shipping === 0 ? "Complimentary" : formatPrice(shipping)}</span>
              </div>
              <div className="flex justify-between text-[#796e67]">
                <span>Estimated tax</span><span>Calculated at checkout</span>
              </div>
              <div className="font-display flex justify-between border-t border-[#eee5dd] pt-4 text-2xl text-[#2d2420]">
                <span>Total</span><span>{formatPrice(total)}</span>
              </div>
            </div>
            <Link href="/checkout" className="mt-7 flex items-center justify-center gap-2 rounded-full bg-[#2d2420] py-4 text-xs font-semibold uppercase tracking-[0.16em] text-white transition hover:bg-[#b47c6f]">
              Proceed to checkout <ArrowRight size={15} />
            </Link>
            <p className="mt-4 text-center text-[11px] leading-5 text-[#9c8d83]">
              Secure demo checkout · Easy 30-day returns
            </p>
          </aside>
        </div>
      )}
    </div>
  );
}
