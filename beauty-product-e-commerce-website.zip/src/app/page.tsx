import Link from "next/link";
import {
  ArrowRight,
  Droplets,
  Leaf,
  ShieldCheck,
  Sparkles,
  Star,
  Truck,
} from "lucide-react";

import { ProductCard } from "@/components/product-card";
import { getFeaturedProducts, getProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";

const categoryEditorial = [
  {
    name: "Skincare",
    description: "Gentle actives, lasting hydration",
    imageUrl:
      "https://images.pexels.com/photos/6767761/pexels-photo-6767761.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  },
  {
    name: "Makeup",
    description: "Soft color, effortless finish",
    imageUrl:
      "https://images.pexels.com/photos/7256140/pexels-photo-7256140.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  },
  {
    name: "Fragrance",
    description: "Quietly memorable scents",
    imageUrl:
      "https://images.pexels.com/photos/13875786/pexels-photo-13875786.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  },
  {
    name: "Body",
    description: "Everyday rituals, softened",
    imageUrl:
      "https://images.pexels.com/photos/4202328/pexels-photo-4202328.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  },
];

const rituals = [
  {
    number: "01",
    title: "Cleanse gently",
    copy: "Begin with a low-foam cleanser that respects your skin barrier and leaves nothing behind but comfort.",
    icon: Droplets,
  },
  {
    number: "02",
    title: "Treat with intention",
    copy: "Press in a targeted serum while skin is damp, letting each active layer absorb slowly and evenly.",
    icon: Sparkles,
  },
  {
    number: "03",
    title: "Seal the glow",
    copy: "Finish with a cushiony cream or oil to lock in hydration and carry that soft luminosity all day.",
    icon: Leaf,
  },
];

const faqs = [
  {
    question: "Are your products suitable for sensitive skin?",
    answer:
      "Most of our formulas are fragrance-conscious and made with calming ingredients. We always recommend patch testing and reviewing the full ingredient list before use.",
  },
  {
    question: "When will my order ship?",
    answer:
      "Orders placed before 2pm are prepared the same business day. Standard delivery usually arrives in 3–5 business days, and shipping is complimentary over $50.",
  },
  {
    question: "Can I return a product?",
    answer:
      "Yes. Unused or lightly tested items can be returned within 30 days for a refund. Contact our team and we will make the process easy.",
  },
];

export default async function HomePage() {
  const [featured, allProducts] = await Promise.all([
    getFeaturedProducts(4),
    getProducts(),
  ]);

  return (
    <>
      <section className="relative overflow-hidden bg-[#f9f2eb]">
        <div className="mx-auto grid max-w-[1400px] items-stretch gap-0 lg:grid-cols-[1.03fr_0.97fr]">
          <div className="animate-fade-up flex flex-col justify-center px-6 pb-12 pt-14 sm:px-10 lg:px-16 lg:py-20 xl:px-24">
            <div className="flex items-center gap-3 text-[10px] font-semibold uppercase tracking-[0.26em] text-[#a9605b]">
              <span className="h-px w-9 bg-[#b47c6f]" /> Clean beauty, quiet luxury
            </div>
            <h1 className="font-display mt-7 max-w-xl text-[clamp(3.3rem,6.6vw,6.2rem)] leading-[0.96] text-[#2d2420]">
              Your skin, <em className="text-[#b47c6f]">in full</em> bloom.
            </h1>
            <p className="mt-7 max-w-lg text-base leading-7 text-[#756a63] sm:text-lg">
              Considered formulas, sensorial textures and a little moment of calm in every bottle. Beauty that feels as good as it looks.
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <Link
                href="/shop"
                className="inline-flex items-center gap-2 rounded-full bg-[#2d2420] px-8 py-4 text-xs font-semibold uppercase tracking-[0.16em] text-white transition hover:bg-[#b47c6f]"
              >
                Shop the collection <ArrowRight size={15} />
              </Link>
              <Link
                href="/#story"
                className="text-xs font-semibold uppercase tracking-[0.16em] text-[#5c5049] underline decoration-[#cbb5a8] underline-offset-8 transition hover:text-[#b47c6f]"
              >
                Discover our story
              </Link>
            </div>
            <div className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-4 border-t border-[#e5d7cd] pt-7">
              <div className="flex items-center gap-3">
                <div className="flex -space-x-2">
                  {["#c89f8b", "#8e9c8a", "#d9b9a4", "#7c6b61"].map((color) => (
                    <span
                      key={color}
                      className="h-9 w-9 rounded-full border-2 border-[#f9f2eb]"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
                <div className="text-xs leading-5 text-[#756a63]">
                  <span className="flex items-center gap-1 font-semibold text-[#2d2420]">
                    {[0, 1, 2, 3, 4].map((index) => (
                      <Star key={index} size={11} className="fill-[#c79a62] text-[#c79a62]" />
                    ))} 4.9
                  </span>
                  Loved by 12,000+ glow getters
                </div>
              </div>
              <p className="text-xs italic text-[#8a7c73]">“A ritual I actually look forward to.”</p>
            </div>
          </div>

          <div className="relative min-h-[430px] lg:min-h-[720px]">
            <img
              src="/images/hero-beauty.jpg"
              alt="Luxury skincare serum, cream jar and lipstick styled with orchid petals"
              className="absolute inset-0 h-full w-full object-cover"
            />
            <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between rounded-2xl border border-white/50 bg-white/80 px-5 py-4 backdrop-blur-md sm:bottom-10 sm:left-10 sm:right-10">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#a9605b]">The glow edit</p>
                <p className="font-display mt-1 text-xl text-[#2d2420]">The everyday essentials</p>
              </div>
              <Link
                href="/shop"
                aria-label="Shop the glow edit"
                className="grid h-11 w-11 place-items-center rounded-full bg-[#2d2420] text-white transition hover:bg-[#b47c6f]"
              >
                <ArrowRight size={17} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="border-y border-[#eee5dd] bg-[#fffcf8]">
        <div className="mx-auto grid max-w-[1400px] grid-cols-2 gap-y-6 px-5 py-7 text-center lg:grid-cols-4 lg:px-10">
          {[
            { icon: Leaf, title: "Clean formulas", sub: "Thoughtfully selected" },
            { icon: ShieldCheck, title: "Dermatologist tested", sub: "Gentle by design" },
            { icon: Truck, title: "Free shipping $50+", sub: "Delivered with care" },
            { icon: Sparkles, title: "Cruelty-free", sub: "Always, without exception" },
          ].map((item) => (
            <div key={item.title} className="flex items-center justify-center gap-3">
              <item.icon size={22} strokeWidth={1.4} className="text-[#b47c6f]" />
              <div className="text-left">
                <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[#3b2c28]">{item.title}</p>
                <p className="mt-0.5 text-[11px] text-[#9c8d83]">{item.sub}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-5 py-16 lg:px-10 lg:py-24">
        <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.26em] text-[#b47c6f]">Shop by category</p>
            <h2 className="font-display mt-3 text-4xl text-[#2d2420] sm:text-5xl">Find your little luxury</h2>
          </div>
          <Link href="/shop" className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-[#5c5049] hover:text-[#b47c6f]">
            View everything <ArrowRight size={15} />
          </Link>
        </div>
        <div className="mt-9 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {categoryEditorial.map((category) => {
            const count = allProducts.filter((product) => product.category === category.name).length;
            return (
              <Link
                key={category.name}
                href={`/shop?category=${encodeURIComponent(category.name)}`}
                className="group relative aspect-[4/5] overflow-hidden rounded-[1.5rem] bg-[#efe7df]"
              >
                <img
                  src={category.imageUrl}
                  alt={`${category.name} beauty products`}
                  loading="lazy"
                  className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#2d2420]/70 via-[#2d2420]/5 to-transparent" />
                <div className="absolute inset-x-5 bottom-5 text-white">
                  <p className="text-[10px] uppercase tracking-[0.18em] text-white/75">{count} products</p>
                  <h3 className="font-display mt-1 text-3xl">{category.name}</h3>
                  <p className="mt-1 text-xs text-white/85">{category.description}</p>
                  <span className="mt-4 inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/60 transition group-hover:bg-white group-hover:text-[#2d2420]">
                    <ArrowRight size={15} />
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      <section className="bg-[#f7f0ea] py-16 lg:py-24">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <div className="text-center">
            <p className="text-[10px] font-semibold uppercase tracking-[0.26em] text-[#b47c6f]">Loved for a reason</p>
            <h2 className="font-display mt-3 text-4xl sm:text-5xl">The bestsellers</h2>
            <p className="mx-auto mt-4 max-w-xl text-sm leading-6 text-[#796e67]">
              The formulas our community reaches for again and again — a beautiful place to begin your ritual.
            </p>
          </div>
          <div className="mt-11 grid gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
            {featured.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          <div className="mt-12 text-center">
            <Link href="/shop" className="inline-flex items-center gap-2 rounded-full border border-[#cbb5a8] px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.16em] text-[#3b2c28] transition hover:bg-[#2d2420] hover:text-white">
              Shop all products <ArrowRight size={15} />
            </Link>
          </div>
        </div>
      </section>

      <section id="story" className="scroll-mt-28 bg-[#fffcf8] py-16 lg:py-24">
        <div className="mx-auto grid max-w-[1400px] items-center gap-10 px-5 lg:grid-cols-2 lg:gap-16 lg:px-10">
          <div className="relative">
            <img
              src="/images/ritual-banner.jpg"
              alt="Hands holding a frosted serum bottle in a serene skincare ritual"
              className="h-[380px] w-full rounded-[1.6rem] object-cover sm:h-[520px]"
            />
            <div className="absolute -bottom-5 -right-2 hidden rounded-2xl bg-[#b47c6f] px-7 py-5 text-white shadow-xl sm:block">
              <p className="font-display text-3xl">98%</p>
              <p className="mt-1 max-w-[140px] text-[10px] uppercase leading-4 tracking-[0.14em] text-white/85">
                said skin felt more hydrated in 2 weeks
              </p>
            </div>
          </div>
          <div className="lg:pl-6">
            <p className="text-[10px] font-semibold uppercase tracking-[0.26em] text-[#b47c6f]">Our philosophy</p>
            <h2 className="font-display mt-4 max-w-lg text-4xl leading-[1.08] sm:text-5xl">
              Beauty that feels like <em className="text-[#b47c6f]">you.</em>
            </h2>
            <p className="mt-6 max-w-xl text-sm leading-7 text-[#796e67]">
              We believe a routine should be a pause, not a prescription. Lumière was created around a simple idea: fewer, better products that respect your skin and fit quietly into real life.
            </p>
            <p className="mt-4 max-w-xl text-sm leading-7 text-[#796e67]">
              Every formula is developed with purposeful actives, elegant textures and a restraint that lets your natural radiance lead.
            </p>
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {["Purposeful ingredients", "Sensorial, skin-friendly textures", "Responsible packaging", "Made without cruelty"].map((value) => (
                <div key={value} className="flex items-center gap-3 rounded-2xl border border-[#eee5dd] bg-[#fbf6f1] px-4 py-3.5 text-xs font-medium text-[#574c46]">
                  <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-[#e8d4ce] text-[#a9605b]">✦</span>
                  {value}
                </div>
              ))}
            </div>
            <Link href="/shop?category=Skincare" className="mt-9 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-[#a9605b] underline underline-offset-8">
              Explore skincare <ArrowRight size={15} />
            </Link>
          </div>
        </div>
      </section>

      <section className="bg-[#efe5dd] py-16 lg:py-24">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <div className="text-center">
            <p className="text-[10px] font-semibold uppercase tracking-[0.26em] text-[#a9605b]">The Lumière ritual</p>
            <h2 className="font-display mt-3 text-4xl sm:text-5xl">Three unhurried steps</h2>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {rituals.map((ritual) => (
              <div key={ritual.number} className="rounded-[1.5rem] bg-[#fffcf8] p-8 shadow-[0_14px_50px_rgba(70,48,38,0.05)]">
                <div className="flex items-start justify-between">
                  <span className="grid h-12 w-12 place-items-center rounded-full bg-[#f4e7e1] text-[#b47c6f]">
                    <ritual.icon size={21} strokeWidth={1.5} />
                  </span>
                  <span className="font-display text-4xl text-[#e4d7ce]">{ritual.number}</span>
                </div>
                <h3 className="font-display mt-8 text-2xl">{ritual.title}</h3>
                <p className="mt-3 text-sm leading-6 text-[#796e67]">{ritual.copy}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="faq" className="scroll-mt-28 mx-auto grid max-w-[1400px] gap-10 px-5 py-16 lg:grid-cols-[0.85fr_1.15fr] lg:gap-20 lg:px-10 lg:py-24">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.26em] text-[#b47c6f]">Good to know</p>
          <h2 className="font-display mt-3 text-4xl leading-tight sm:text-5xl">A few common questions</h2>
          <p className="mt-5 max-w-sm text-sm leading-6 text-[#796e67]">
            Still wondering about a formula or an order? Our beauty team is always happy to help at hello@lumierebeauty.com.
          </p>
          <div className="mt-8 rounded-2xl bg-[#f7f0ea] p-6">
            <p className="font-display text-lg leading-6 text-[#3b2c28]">“Finally, products that feel calm, considered and genuinely lovely to use.”</p>
            <p className="mt-4 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#a9605b]">— Amelia R., verified customer</p>
          </div>
        </div>
        <div className="border-t border-[#e9e0d8]">
          {faqs.map((faq) => (
            <details key={faq.question} className="group border-b border-[#e9e0d8] py-5" open={faq === faqs[0]}>
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-display text-xl text-[#2d2420] [&::-webkit-details-marker]:hidden">
                {faq.question}
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-[#e1d5cc] text-lg text-[#b47c6f] transition group-open:rotate-45">+</span>
              </summary>
              <p className="mt-3 max-w-xl text-sm leading-6 text-[#796e67]">{faq.answer}</p>
            </details>
          ))}
        </div>
      </section>
    </>
  );
}
