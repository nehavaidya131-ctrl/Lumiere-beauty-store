import Link from "next/link";
import { ArrowRight, RotateCcw, Search, SlidersHorizontal } from "lucide-react";

import { ProductCard } from "@/components/product-card";
import { getCategories, getProducts } from "@/lib/catalog";
import { firstParam } from "@/lib/format";
import type { ProductFilters } from "@/lib/types";

export const dynamic = "force-dynamic";

type SearchParams = Record<string, string | string[] | undefined>;

const priceOptions = [
  { label: "All prices", value: "" },
  { label: "Under $30", value: "30" },
  { label: "Under $50", value: "50" },
  { label: "Under $100", value: "100" },
];

export default async function ShopPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const params = await searchParams;
  const category = firstParam(params.category) ?? "";
  const q = firstParam(params.q) ?? "";
  const max = firstParam(params.max) ?? "";
  const sortValue = firstParam(params.sort) ?? "featured";
  const sort: ProductFilters["sort"] = [
    "featured",
    "price-low",
    "price-high",
    "newest",
    "rating",
  ].includes(sortValue)
    ? (sortValue as ProductFilters["sort"])
    : "featured";
  const maxPrice = max ? Number(max) : undefined;

  const [products, categories] = await Promise.all([
    getProducts({
      category: category || undefined,
      q: q || undefined,
      maxPrice: Number.isFinite(maxPrice) ? maxPrice : undefined,
      sort,
    }),
    getCategories(),
  ]);

  const baseParams = new URLSearchParams();
  if (q) baseParams.set("q", q);
  if (category) baseParams.set("category", category);
  if (max) baseParams.set("max", max);
  if (sortValue !== "featured") baseParams.set("sort", sortValue);

  const urlWith = (changes: Record<string, string>) => {
    const next = new URLSearchParams(baseParams);
    for (const [key, value] of Object.entries(changes)) {
      if (value) next.set(key, value);
      else next.delete(key);
    }
    const query = next.toString();
    return query ? `/shop?${query}` : "/shop";
  };

  return (
    <>
      <section className="border-b border-[#eee5dd] bg-[#f7f0ea] px-5 py-12 lg:px-10 lg:py-16">
        <div className="mx-auto max-w-[1400px]">
          <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-[#a9605b]">
            Home <span className="mx-2 text-[#cbb5a8]">/</span> The beauty edit
          </p>
          <div className="mt-4 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
            <div>
              <h1 className="font-display text-5xl leading-none sm:text-6xl">
                {category || (q ? `Results for “${q}”` : "All beauty")}
              </h1>
              <p className="mt-4 max-w-xl text-sm leading-6 text-[#796e67]">
                Thoughtfully made skincare, color, fragrance and body essentials. Find the pieces that make your routine yours.
              </p>
            </div>
            <p className="text-xs font-medium uppercase tracking-[0.15em] text-[#8a7c73]">
              {products.length} {products.length === 1 ? "product" : "products"}
            </p>
          </div>
        </div>
      </section>

      <div className="mx-auto grid max-w-[1400px] gap-8 px-5 py-10 lg:grid-cols-[240px_1fr] lg:gap-12 lg:px-10 lg:py-14">
        <aside className="space-y-8">
          <div className="rounded-2xl border border-[#e9e0d8] bg-white p-5">
            <h2 className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-[#3b2c28]">
              <SlidersHorizontal size={14} /> Refine
            </h2>
            <div className="mt-5">
              <p className="mb-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#aa9b91]">Category</p>
              <div className="space-y-1">
                <Link
                  href={urlWith({ category: "" })}
                  className={`block rounded-lg px-3 py-2 text-sm transition ${
                    !category ? "bg-[#f4e7e1] font-semibold text-[#a9605b]" : "text-[#756a63] hover:bg-[#fbf6f1]"
                  }`}
                >
                  All products
                </Link>
                {categories.map((name) => (
                  <Link
                    key={name}
                    href={urlWith({ category: name })}
                    className={`block rounded-lg px-3 py-2 text-sm transition ${
                      category === name ? "bg-[#f4e7e1] font-semibold text-[#a9605b]" : "text-[#756a63] hover:bg-[#fbf6f1]"
                    }`}
                  >
                    {name}
                  </Link>
                ))}
              </div>
            </div>
            <div className="mt-6 border-t border-[#eee5dd] pt-6">
              <p className="mb-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#aa9b91]">Price</p>
              <div className="space-y-1">
                {priceOptions.map((option) => (
                  <Link
                    key={option.label}
                    href={urlWith({ max: option.value })}
                    className={`block rounded-lg px-3 py-2 text-sm transition ${
                      max === option.value ? "bg-[#f4e7e1] font-semibold text-[#a9605b]" : "text-[#756a63] hover:bg-[#fbf6f1]"
                    }`}
                  >
                    {option.label}
                  </Link>
                ))}
              </div>
            </div>
            <Link href="/shop" className="mt-6 flex items-center gap-2 border-t border-[#eee5dd] pt-5 text-[11px] font-semibold uppercase tracking-[0.14em] text-[#a9605b]">
              <RotateCcw size={13} /> Clear filters
            </Link>
          </div>

          <div className="hidden rounded-2xl bg-[#3b2c28] p-6 text-white lg:block">
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#d8b8aa]">A little extra</p>
            <h3 className="font-display mt-3 text-2xl leading-tight">Complimentary shipping over $50</h3>
            <p className="mt-3 text-xs leading-5 text-white/70">Plus a curated sample in every order, chosen for your routine.</p>
          </div>
        </aside>

        <div>
          <div className="mb-8 flex flex-col justify-between gap-4 rounded-2xl border border-[#e9e0d8] bg-white p-3 sm:flex-row sm:items-center">
            <form action="/shop" method="get" className="flex flex-1 items-center gap-2 rounded-xl bg-[#fbf7f3] px-4 py-2.5">
              <Search size={16} className="text-[#a38f84]" />
              <input
                type="search"
                name="q"
                defaultValue={q}
                placeholder="Search products, brands, ingredients..."
                aria-label="Search products"
                className="w-full bg-transparent text-sm outline-none placeholder:text-[#ab9e95]"
              />
              {category && <input type="hidden" name="category" value={category} />}
              {max && <input type="hidden" name="max" value={max} />}
              {sortValue !== "featured" && <input type="hidden" name="sort" value={sortValue} />}
              <button type="submit" className="text-[10px] font-bold uppercase tracking-[0.14em] text-[#a9605b]">
                Search
              </button>
            </form>
            <form action="/shop" method="get" className="flex items-center gap-3 sm:pr-2">
              {q && <input type="hidden" name="q" value={q} />}
              {category && <input type="hidden" name="category" value={category} />}
              {max && <input type="hidden" name="max" value={max} />}
              <label htmlFor="sort" className="whitespace-nowrap text-[10px] font-semibold uppercase tracking-[0.14em] text-[#9c8d83]">
                Sort by
              </label>
              <select
                id="sort"
                name="sort"
                defaultValue={sort}
                className="rounded-lg border border-[#e9e0d8] bg-white px-3 py-2 text-xs font-medium text-[#3b2c28] outline-none"
              >
                <option value="featured">Featured</option>
                <option value="price-low">Price: low to high</option>
                <option value="price-high">Price: high to low</option>
                <option value="rating">Top rated</option>
                <option value="newest">Newest</option>
              </select>
              <button type="submit" className="grid h-9 w-9 place-items-center rounded-lg bg-[#f4e7e1] text-[#a9605b]" aria-label="Apply sort">
                <ArrowRight size={15} />
              </button>
            </form>
          </div>

          {products.length > 0 ? (
            <div className="grid gap-x-6 gap-y-11 sm:grid-cols-2 xl:grid-cols-3">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="rounded-[1.5rem] border border-dashed border-[#ddcec3] bg-[#fbf7f3] px-8 py-20 text-center">
              <h2 className="font-display text-3xl">Nothing quite matched</h2>
              <p className="mx-auto mt-3 max-w-md text-sm leading-6 text-[#796e67]">
                Try another search term or browse the full collection — your next favorite may be one click away.
              </p>
              <Link href="/shop" className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#2d2420] px-7 py-3 text-xs font-semibold uppercase tracking-[0.15em] text-white hover:bg-[#b47c6f]">
                View all products <ArrowRight size={15} />
              </Link>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
